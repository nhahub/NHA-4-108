import pandas as pd
from sqlalchemy import create_engine
import urllib

# =========================================================
# Part 1: Reading the CSV file (preparing the raw material)
# =========================================================
print("1. Loading RAW CSV file...")
# Put here the path of your file on your machine (e.g. in the Downloads folder)
file_path = r"C:\temp\encounters_v2.csv"

# We read the file, and dtype=str means: "read everything as strings so the server doesn't throw an error"
df_raw = pd.read_csv(file_path, dtype=str)

# We strip any spaces from column names to match what we created in SQL
df_raw.columns = df_raw.columns.str.strip()
print(f"Loaded {len(df_raw)} rows.")

# =========================================================
# Part 2: Building the bridge between Python and SQL
# =========================================================
print("2. Connecting to SQL Server...")

# ⚠️ Delete 'YOUR_SERVER_NAME' and put the name you copied from SSMS
server_name = r'LAPTOP-DKMU9MJP\SQLEXPRESS' 
database_name = 'HealthcareDB'

# This is a fixed code that builds the bridge (Connection String)
params = urllib.parse.quote_plus(
    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
    f'SERVER={server_name};'
    f'DATABASE={database_name};'
    f'Trusted_Connection=yes;'
)
engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}", fast_executemany=True)

# =========================================================
# Part 3: Pushing the data into the basement (Bronze Layer)
# =========================================================
print("3. Uploading data to Bronze Layer in chunks...")

# This function takes the data in Python and pushes it into the server
# We added chunksize so it uploads the data 10,000 rows at a time and doesn't hang
df_raw.to_sql(
    name='healthcare_raw', 
    schema='bronze', 
    con=engine, 
    if_exists='replace', # Instead of append so it deletes the old data and loads the new
    index=False,
    chunksize=10000
)

print("✅ Data uploaded successfully to SQL Server!")