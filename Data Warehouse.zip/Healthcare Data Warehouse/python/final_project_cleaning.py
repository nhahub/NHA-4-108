# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════╗
║         Hospital Encounters — Data Cleaning Pipeline v2          ║
║         DEPI — Data Analysis Track | Healthcare Project          ║
╚══════════════════════════════════════════════════════════════════╝

Dataset : encounters_v2.csv  (103 columns — HIPAA Safe Harbor)
Steps   : Load → EDA → Data Types → Binary Check → Range Check
          → Timestamp Logic Fix → Save
Note    : No imputation (blanks stay as-is per instructor).
          No calculated columns (handled in Power BI).
"""

# ══════════════════════════════════════════════════════════════════
# SECTION 1 — Import Libraries
# ══════════════════════════════════════════════════════════════════
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

print("✅ Libraries imported successfully.")

# ══════════════════════════════════════════════════════════════════
# SECTION 2 — Load Dataset
# ══════════════════════════════════════════════════════════════════
df = pd.read_csv(r"/content/encounters_v2.csv")

print(f"\n📂 Dataset loaded successfully.")
print(f"   Rows    : {df.shape[0]:,}")
print(f"   Columns : {df.shape[1]}")

# ══════════════════════════════════════════════════════════════════
# SECTION 3 — Exploratory Data Analysis (EDA)
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 3 — EDA")
print("="*55)

# ── 3.1 Basic Info ────────────────────────────────────────────────
print("\n[3.1] Dataset Info:")
df.info()

# ── 3.2 Shape ─────────────────────────────────────────────────────
print(f"\n[3.2] Shape: {df.shape}")

# ── 3.3 Statistical Summary ───────────────────────────────────────
print("\n[3.3] Statistical Summary:")
print(df.describe().round(2))

# ── 3.4 Duplicate Check ───────────────────────────────────────────
dup_count = df.duplicated().sum()
print(f"\n[3.4] Duplicate rows: {dup_count}")
if dup_count == 0:
    print("      ✅ No duplicates found.")
else:
    print(f"      ⚠️  {dup_count} duplicate rows detected.")

# ── 3.5 Missing Values ────────────────────────────────────────────
print("\n[3.5] Missing Values per Column:")
null_counts = df.isnull().sum()
null_cols   = null_counts[null_counts > 0]
if null_cols.empty:
    print("      ✅ No missing values found.")
else:
    print(null_cols.to_string())
    print(f"\n      Total columns with nulls : {len(null_cols)}")
    print(f"      Total missing cells      : {null_counts.sum():,}")
    print("\n      ℹ️  NOTE: These nulls are STRUCTURAL (intentional by design).")
    print("      Per instructor instruction — DO NOT impute. Leave as-is.")

# ── 3.6 Current Data Types ────────────────────────────────────────
pd.set_option('display.max_rows', None)
print("\n[3.6] Current Data Types:")
print(df.dtypes.to_string())

# ══════════════════════════════════════════════════════════════════
# SECTION 4 — EDA Visualizations
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 4 — EDA Visualizations")
print("="*55)

# ── Plot 1: Severity Index Distribution ───────────────────────────
plt.figure(figsize=(8, 5))
plt.hist(df["severity_index"], bins=40,
         color="steelblue", edgecolor="white", alpha=0.85)
plt.axvline(df["severity_index"].mean(), color="#E74C3C",
            lw=2, linestyle="--",
            label=f'Mean = {df["severity_index"].mean():.2f}')
plt.title("Severity Index Distribution", fontsize=13)
plt.xlabel("Severity Index")
plt.ylabel("Count")
plt.legend()
plt.tight_layout()
plt.show()

# ── Plot 2: 30-Day Readmission Rate by Diagnosis Category ─────────
plt.figure(figsize=(9, 5))
readmit = (df.groupby("diagnosis_category")["readmission_30d_flag"]
             .mean()
             .sort_values(ascending=False) * 100)
bars = plt.bar(readmit.index, readmit.values,
               color="steelblue", edgecolor="white")
plt.bar_label(bars, fmt="%.1f%%", padding=3)
plt.axhline(15, color="#E74C3C", lw=1.5, linestyle="--",
            label="CMS Benchmark (15%)")
plt.title("30-Day Readmission Rate by Diagnosis Category", fontsize=13)
plt.ylabel("Readmission Rate (%)")
plt.xlabel("Diagnosis Category")
plt.xticks(rotation=30)
plt.legend()
plt.tight_layout()
plt.show()

# ── Plot 3: HAI Rate by Unit ──────────────────────────────────────
plt.figure(figsize=(9, 5))
hai_unit = (df.groupby("unit_assigned")["hai_flag"]
              .mean()
              .sort_values(ascending=False) * 100)
bars = plt.bar(hai_unit.index, hai_unit.values,
               color="steelblue", edgecolor="white")
plt.bar_label(bars, fmt="%.1f%%", padding=3)
plt.axhline(3, color="#E74C3C", lw=1.5, linestyle="--",
            label="CMS HACRP Benchmark (3%)")
plt.title("Hospital-Acquired Infection (HAI) Rate by Unit", fontsize=13)
plt.ylabel("HAI Rate (%)")
plt.xlabel("Unit Assigned")
plt.xticks(rotation=30)
plt.legend()
plt.tight_layout()
plt.show()

# ── Plot 4: Length of Stay by Diagnosis ───────────────────────────
plt.figure(figsize=(9, 5))
sns.boxplot(data=df, x="diagnosis_category", y="los_days",
            color="steelblue")
plt.title("Length of Stay (Days) by Diagnosis Category", fontsize=13)
plt.xlabel("Diagnosis Category")
plt.ylabel("LOS (Days)")
plt.xticks(rotation=30)
plt.tight_layout()
plt.show()

# ── Plot 5: Claim Denial Rate by Payer ────────────────────────────
plt.figure(figsize=(9, 5))
denial_payer = (df.groupby("payer")["claim_denial_flag"]
                  .mean()
                  .sort_values(ascending=False) * 100)
bars = plt.bar(denial_payer.index, denial_payer.values,
               color="tomato", edgecolor="white")
plt.bar_label(bars, fmt="%.1f%%", padding=3)
plt.axhline(10, color="#2C3E50", lw=1.5, linestyle="--",
            label="Target Denial Rate (10%)")
plt.title("Claim Denial Rate by Payer", fontsize=13)
plt.ylabel("Denial Rate (%)")
plt.xlabel("Payer")
plt.xticks(rotation=20)
plt.legend()
plt.tight_layout()
plt.show()

# ── Plot 6: Burnout Distribution by Nurse Role ────────────────────
plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x="nurse_role", y="burnout_exhaustion_mbi",
            color="steelblue")
plt.axhline(3.5, color="#E74C3C", lw=1.5, linestyle="--",
            label="High Burnout Threshold (MBI ≥ 3.5)")
plt.title("MBI Emotional Exhaustion by Nurse Role", fontsize=13)
plt.xlabel("Nurse Role")
plt.ylabel("Burnout Exhaustion Score (0–6)")
plt.legend()
plt.tight_layout()
plt.show()

print("✅ All 6 visualizations complete.")

# ══════════════════════════════════════════════════════════════════
# SECTION 5 — Data Type Corrections
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 5 — Data Type Corrections")
print("="*55)

# ── 5.1 DateTime Columns (8 columns) ─────────────────────────────
datetime_cols = [
    "triage_timestamp",
    "physician_assessment_timestamp",
    "admit_timestamp",
    "bed_request_time",
    "bed_assign_time",
    "or_start",
    "or_end",
    "discharge_timestamp",
]

converted_dt, failed_dt = [], []
for col in datetime_cols:
    if col in df.columns:
        df[col] = pd.to_datetime(df[col], errors="coerce")
        converted_dt.append(col)
    else:
        failed_dt.append(col)

print(f"\n[5.1] DateTime columns converted ({len(converted_dt)}):")
for c in converted_dt:
    nulls_after = df[c].isnull().sum()
    print(f"      ✅ {c:<45} | parse failures: {nulls_after}")
if failed_dt:
    print(f"      ⚠️  Not found: {failed_dt}")

# ── 5.2 Date Columns (2 columns) ─────────────────────────────────
date_cols = [
    "appointment_request_date",
    "kit_expiration_date",
]

converted_d = []
for col in date_cols:
    if col in df.columns:
        df[col] = pd.to_datetime(df[col], errors="coerce").dt.date
        converted_d.append(col)

print(f"\n[5.2] Date columns converted ({len(converted_d)}):")
for c in converted_d:
    print(f"      ✅ {c}")

# ── 5.3 String Columns (must NOT be numeric) ──────────────────────
# npi_billing  : 10-digit identifier — must be string
# cpt_code     : procedure code — must be string
string_id_cols = {
    "npi_billing": 10,   # zero-pad to 10 digits
    "cpt_code":    None, # just convert to str
}

print(f"\n[5.3] Identifier columns fixed to String:")
for col, pad in string_id_cols.items():
    if col in df.columns:
        if pad:
            df[col] = df[col].astype(str).str.zfill(pad)
            print(f"      ✅ {col:<20} → str (zero-padded to {pad} chars)")
        else:
            df[col] = df[col].astype(str)
            print(f"      ✅ {col:<20} → str")

# ── 5.4 Float Columns (35 columns) ───────────────────────────────
float_cols = [
    "severity_index", "sbp_mmhg", "dbp_mmhg", "heart_rate_bpm",
    "spo2_pct", "temperature_f", "bmi", "hba1c_pct", "glucose_mg_dl",
    "creatinine_mg_dl", "wbc_10e3_ul", "nt_probnp_pg_ml",
    "medication_adherence_pdc", "bed_occupancy_pct", "drg_weight",
    "submitted_charge_usd", "allowed_amount_usd",
    "patient_responsibility_usd", "consumable_supply_cost_usd",
    "nurse_tenure_years", "nurse_fte", "overtime_hours",
    "burnout_exhaustion_mbi", "burnout_cynicism_mbi",
    "turnover_risk_index", "cahps_nurse_communication",
    "cahps_doctor_communication", "cahps_responsiveness",
    "cahps_pain_management", "cahps_discharge_info",
    "cahps_care_transition", "cahps_cleanliness", "cahps_quietness",
    "kit_unit_cost_usd", "days_of_supply",
]

fixed_float = []
for col in float_cols:
    if col in df.columns and df[col].dtype != "float64":
        df[col] = pd.to_numeric(df[col], errors="coerce")
        fixed_float.append(col)

print(f"\n[5.4] Float columns verified ({len(float_cols)}).")
if fixed_float:
    print(f"      Fixed {len(fixed_float)} columns: {fixed_float}")
else:
    print(f"      ✅ All float columns already correct.")

# ── 5.5 Integer Columns (17 columns) ─────────────────────────────
int_cols = [
    "birth_year", "age", "comorbidity_count", "respiratory_rate",
    "actual_or_minutes", "or_turnover_minutes", "los_days",
    "equipment_usage_minutes", "shift_hours", "patients_per_nurse_ratio",
    "patient_reported_wait_time_mins", "kit_current_stock",
    "kit_reorder_point", "kit_lead_time_days", "weekly_procedure_volume",
    "projected_demand_4wk", "himss_emram_stage",
]

fixed_int = []
for col in int_cols:
    if col in df.columns and df[col].dtype not in ["int64", "int32"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        fixed_int.append(col)

print(f"\n[5.5] Integer columns verified ({len(int_cols)}).")
if fixed_int:
    print(f"      Fixed {len(fixed_int)} columns: {fixed_int}")
else:
    print(f"      ✅ All integer columns already correct.")

# ── 5.6 Strip Whitespace from all String Columns ─────────────────
text_cols = df.select_dtypes(include=["object"]).columns
for col in text_cols:
    df[col] = df[col].str.strip()

print(f"\n[5.6] Stripped whitespace from {len(text_cols)} string columns. ✅")

# ══════════════════════════════════════════════════════════════════
# SECTION 6 — Binary Column Validation
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 6 — Binary Column Validation")
print("="*55)

binary_cols = [
    "has_diabetes", "has_hypertension", "has_chf",
    "readmission_30d_flag", "hai_flag", "follow_up_within_48h_flag",
    "safety_incident_flag", "fraud_upcoding_flag",
    "fraud_duplicate_flag", "fraud_unbundling_flag",
    "claim_denial_flag", "telehealth_used_flag",
    "stockout_risk_flag", "hedis_hba1c_tested",
    "hedis_hba1c_poor_control",
]

problems = []
for col in binary_cols:
    if col in df.columns:
        unique_vals = set(df[col].dropna().unique())
        invalid     = unique_vals - {0, 1}
        if invalid:
            problems.append(col)
            print(f"   ⚠️  {col:<35} → invalid values: {invalid}")
        else:
            print(f"   ✅  {col}")

print()
if not problems:
    print("✅ All 15 binary columns are clean — values are 0 or 1 only.")
else:
    print(f"⚠️  {len(problems)} column(s) have invalid values — manual review needed.")

# ══════════════════════════════════════════════════════════════════
# SECTION 7 — Range Validation
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 7 — Range Validation (Report Only — No Imputation)")
print("="*55)
print("   ℹ️  Per instructor: blanks and out-of-range values are reported")
print("   only. No values are replaced or removed.\n")

range_checks = {
    "age":                      (0,    95,   "HIPAA cap"),
    "severity_index":           (0.0,  1.0,  "Synthetic acuity score"),
    "medication_adherence_pdc": (0.0,  1.0,  "Proportion of Days Covered"),
    "sbp_mmhg":                 (60,   220,  "Systolic blood pressure"),
    "dbp_mmhg":                 (40,   140,  "Diastolic blood pressure"),
    "heart_rate_bpm":           (30,   200,  "Heart rate"),
    "spo2_pct":                 (70,   100,  "Oxygen saturation"),
    "temperature_f":            (94,   106,  "Body temperature"),
    "bmi":                      (10,   70,   "Body mass index"),
    "hba1c_pct":                (4.0,  15.0, "Hemoglobin A1c"),
    "glucose_mg_dl":            (40,   600,  "Serum glucose"),
    "creatinine_mg_dl":         (0.1,  15.0, "Serum creatinine"),
    "wbc_10e3_ul":              (0.5,  50.0, "White blood cell count"),
    "los_days":                 (0,    60,   "Length of stay"),
    "bed_occupancy_pct":        (0,    100,  "Bed occupancy"),
    "burnout_exhaustion_mbi":   (0.0,  6.0,  "MBI Exhaustion [0-6]"),
    "burnout_cynicism_mbi":     (0.0,  6.0,  "MBI Cynicism [0-6]"),
    "turnover_risk_index":      (0.0,  1.0,  "Turnover risk [0-1]"),
    "himss_emram_stage":        (0,    7,    "HIMSS EMRAM [0-7]"),
    "drg_weight":               (0.1,  10.0, "DRG weight"),
    "nurse_fte":                (0.0,  1.0,  "Nurse FTE [0-1]"),
    "shift_hours":              (8,    12,   "Shift hours [8,10,12]"),
    "patients_per_nurse_ratio": (1,    20,   "Patients per nurse"),
    "cahps_nurse_communication":(1.0,  5.0,  "CAHPS score [1-5]"),
    "cahps_doctor_communication":(1.0, 5.0,  "CAHPS score [1-5]"),
    "cahps_responsiveness":     (1.0,  5.0,  "CAHPS score [1-5]"),
    "cahps_pain_management":    (1.0,  5.0,  "CAHPS score [1-5]"),
    "cahps_discharge_info":     (1.0,  5.0,  "CAHPS score [1-5]"),
    "cahps_care_transition":    (1.0,  5.0,  "CAHPS score [1-5]"),
    "cahps_cleanliness":        (1.0,  5.0,  "CAHPS score [1-5]"),
    "cahps_quietness":          (1.0,  5.0,  "CAHPS score [1-5]"),
    "days_of_supply":           (0,    365,  "Days of supply"),
}

out_of_range_found = False
print(f"   {'Column':<35} {'Range':<15} {'Out-of-range':>12}   Description")
print(f"   {'-'*35} {'-'*15} {'-'*12}   {'-'*30}")

for col, (lo, hi, desc) in range_checks.items():
    if col in df.columns:
        mask      = (df[col] < lo) | (df[col] > hi)
        out_count = mask.sum()
        status    = f"{out_count:,}" if out_count > 0 else "✅ 0"
        if out_count > 0:
            out_of_range_found = True
        print(f"   {col:<35} [{lo} – {hi}]  {status:>12}   {desc}")

print()
if not out_of_range_found:
    print("✅ All columns within valid ranges.")
else:
    print("ℹ️  Out-of-range values reported above — left as-is per instruction.")

# ══════════════════════════════════════════════════════════════════
# SECTION 8 — Timestamp Logic Fix
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 8 — Timestamp Logic Fix")
print("="*55)

# ── Rule: physician_assessment must come BEFORE admit_timestamp ───
# If admit_timestamp < physician_assessment_timestamp → swap them
# (doctor must assess patient before formal admission is possible)

if "admit_timestamp" in df.columns and "physician_assessment_timestamp" in df.columns:

    # Count violations before fix
    violation_mask = df["admit_timestamp"] < df["physician_assessment_timestamp"]
    violations_before = violation_mask.sum()

    print(f"\n   [Before Fix] Rows where admit < physician_assessment : {violations_before:,}")

    if violations_before > 0:
        print(f"   ℹ️  Fixing: swapping the two timestamps in {violations_before:,} rows...")

        # Store the admit values temporarily for the swap
        temp = df.loc[violation_mask, "admit_timestamp"].copy()

        # Swap
        df.loc[violation_mask, "admit_timestamp"] = \
            df.loc[violation_mask, "physician_assessment_timestamp"]

        df.loc[violation_mask, "physician_assessment_timestamp"] = temp

        # Verify fix
        violations_after = (
            df["admit_timestamp"] < df["physician_assessment_timestamp"]
        ).sum()

        print(f"   [After Fix]  Remaining violations              : {violations_after:,}")

        if violations_after == 0:
            print("   ✅ All timestamp violations fixed successfully.")
        else:
            print("   ⚠️  Some violations still remain — manual review needed.")
    else:
        print("   ✅ No violations found — timestamps are already correct.")

# ── Additional timestamp order checks (report only) ───────────────
print("\n   [Additional Timestamp Checks — Report Only]")

ts_checks = [
    ("triage_timestamp",              "physician_assessment_timestamp",
     "triage must be BEFORE physician assessment"),
    ("bed_request_time",              "bed_assign_time",
     "bed request must be BEFORE bed assignment"),
    ("or_start",                      "or_end",
     "OR start must be BEFORE OR end"),
    ("admit_timestamp",               "discharge_timestamp",
     "admission must be BEFORE discharge"),
]

for col_a, col_b, desc in ts_checks:
    if col_a in df.columns and col_b in df.columns:
        v = (df[col_b] < df[col_a]).sum()
        status = "✅ OK" if v == 0 else f"⚠️  {v:,} rows"
        print(f"   {status:<15} | {desc}")

# ══════════════════════════════════════════════════════════════════
# SECTION 9 — Final Data Type Summary
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 9 — Final Data Type Summary")
print("="*55)

print(f"\n   {'Column':<45} {'Before→After Type'}")
print(f"   {'-'*45} {'-'*25}")

final_dtypes = df.dtypes
for col, dtype in final_dtypes.items():
    print(f"   {col:<45} {str(dtype)}")

# ══════════════════════════════════════════════════════════════════
# SECTION 10 — Save Clean Dataset
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("  SECTION 10 — Save Clean Dataset")
print("="*55)

output_path = "encounters_v2_CLEAN.csv"
df.to_csv(output_path, index=False)

print(f"\n   ✅ Saved to   : {output_path}")
print(f"   Rows         : {df.shape[0]:,}")
print(f"   Columns      : {df.shape[1]}")
print(f"   Remaining NaN: {df.isnull().sum().sum():,}  (structural nulls — kept as-is)")

# Download in Google Colab
try:
    from google.colab import files
    files.download(output_path)
    print("   ✅ Download started!")
except ImportError:
    print("   ℹ️  Not running in Colab — file saved locally.")

# ══════════════════════════════════════════════════════════════════
# SECTION 11 — Final Pipeline Summary
# ══════════════════════════════════════════════════════════════════
print("\n" + "="*55)
print("       CLEANING PIPELINE — FINAL SUMMARY")
print("="*55)
print(f"  Total Rows              : {df.shape[0]:,}")
print(f"  Total Columns           : {df.shape[1]}")
print(f"  Duplicate Rows          : {df.duplicated().sum()}")
print(f"  Remaining NaN (structural): {df.isnull().sum().sum():,}")
print(f"  DateTime columns fixed  : {len(datetime_cols)}")
print(f"  Date columns fixed      : {len(date_cols)}")
print(f"  String IDs fixed        : {len(string_id_cols)}")
print(f"  Binary cols validated   : {len(binary_cols)}")
print(f"  Range checks run        : {len(range_checks)}")
print(f"  Timestamp swaps applied : {violations_before:,}")
print(f"  Output file             : {output_path}")
print("="*55)
print("  ✅ DONE — Data is clean and ready for SQL & Power BI.")
print("="*55)
