/*
================================================================================
SCRIPT  : 03_create_and_load_gold.sql
PURPOSE : Build the Star Schema and load cleansed data from the Silver layer to the Gold layer.
================================================================================
*/
USE HealthcareDB;
GO

-- ============================================================
-- 1. Safe Teardown (Drop existing tables to ensure a clean state)
-- ============================================================
IF OBJECT_ID('gold.DIM_CLINICAL', 'U') IS NOT NULL DROP TABLE gold.DIM_CLINICAL;
IF OBJECT_ID('gold.DIM_OPERATIONAL', 'U') IS NOT NULL DROP TABLE gold.DIM_OPERATIONAL;
IF OBJECT_ID('gold.DIM_FINANCIAL', 'U') IS NOT NULL DROP TABLE gold.DIM_FINANCIAL;
IF OBJECT_ID('gold.DIM_HR', 'U') IS NOT NULL DROP TABLE gold.DIM_HR;
IF OBJECT_ID('gold.FACT_ENCOUNTERS', 'U') IS NOT NULL DROP TABLE gold.FACT_ENCOUNTERS;
IF OBJECT_ID('gold.DIM_PATIENT', 'U') IS NOT NULL DROP TABLE gold.DIM_PATIENT;
IF OBJECT_ID('gold.DIM_SUPPLY', 'U') IS NOT NULL DROP TABLE gold.DIM_SUPPLY;
IF OBJECT_ID('gold.DIM_DATE', 'U') IS NOT NULL DROP TABLE gold.DIM_DATE;
GO

-- ============================================================
-- 2. Schema Construction (Create the 8 Gold layer tables)
-- ============================================================

CREATE TABLE gold.DIM_DATE (
    date_key        DATE          NOT NULL PRIMARY KEY,
    full_date       DATE          NOT NULL,
    year            SMALLINT      NOT NULL,
    quarter         TINYINT       NOT NULL,   -- 1,2,3,4
    month           TINYINT       NOT NULL,
    month_name      VARCHAR(20)   NOT NULL,
    week_number     TINYINT       NOT NULL,   -- 1-53
    day_of_month    TINYINT       NOT NULL,   -- 1-31
    day_of_week     TINYINT       NOT NULL,   -- 1=Monday...7=Sunday
    day_name        VARCHAR(20)   NOT NULL,
    is_weekend      BIT           NOT NULL
);

CREATE TABLE gold.DIM_PATIENT (
    patient_id VARCHAR(100) NOT NULL PRIMARY KEY,
    birth_year INT,
    age INT,
    gender VARCHAR(10),
    race_ethnicity VARCHAR(50),
    state CHAR(2)
);

CREATE TABLE gold.DIM_SUPPLY (
    surgical_kit_id VARCHAR(20) NOT NULL PRIMARY KEY,
    kit_name VARCHAR(50),
    kit_unit_cost_usd FLOAT,
    kit_current_stock INT,
    kit_reorder_point INT,
    kit_lead_time_days INT,
    kit_expiration_date DATE,
    stockout_risk_flag TINYINT,
    weekly_procedure_volume INT,
    projected_demand_4wk INT,
    days_of_supply FLOAT
);

CREATE TABLE gold.FACT_ENCOUNTERS (
    encounter_id VARCHAR(100) NOT NULL PRIMARY KEY,
    patient_id VARCHAR(100) NOT NULL,
    claim_id VARCHAR(20),
    surgical_kit_id VARCHAR(20),
    nurse_emp_id VARCHAR(20),
    surgeon_emp_id VARCHAR(20),
    admit_date_key DATE,
    triage_timestamp DATETIME2,
    admit_timestamp DATETIME2,
    discharge_timestamp DATETIME2,
    los_days INT,
    readmission_30d_flag TINYINT,
    safety_incident_flag TINYINT,
    hai_flag TINYINT,
    follow_up_within_48h_flag TINYINT,
    himss_emram_stage INT,
    CONSTRAINT FK_FACT_PATIENT FOREIGN KEY (patient_id) REFERENCES gold.DIM_PATIENT(patient_id),
    CONSTRAINT FK_FACT_SUPPLY FOREIGN KEY (surgical_kit_id) REFERENCES gold.DIM_SUPPLY(surgical_kit_id),
    CONSTRAINT FK_FACT_DATE FOREIGN KEY (admit_date_key) REFERENCES gold.DIM_DATE(date_key)
);

CREATE TABLE gold.DIM_CLINICAL (
    encounter_id VARCHAR(100) NOT NULL PRIMARY KEY,
    icd10_code VARCHAR(10),
    diagnosis_display VARCHAR(255),
    diagnosis_category VARCHAR(20),
    severity_index FLOAT,
    comorbidity_count INT,
    has_diabetes TINYINT,
    has_hypertension TINYINT,
    has_chf TINYINT,
    sbp_mmhg FLOAT,
    dbp_mmhg FLOAT,
    heart_rate_bpm FLOAT,
    spo2_pct FLOAT,
    temperature_f FLOAT,
    bmi FLOAT,
    respiratory_rate INT,
    hba1c_pct FLOAT,
    glucose_mg_dl FLOAT,
    creatinine_mg_dl FLOAT,
    wbc_10e3_ul FLOAT,
    nt_probnp_pg_ml FLOAT,
    medication_adherence_pdc FLOAT,
    hedis_hba1c_tested TINYINT,
    hedis_hba1c_poor_control TINYINT,
    CONSTRAINT FK_CLIN_ENCOUNTER FOREIGN KEY (encounter_id) REFERENCES gold.FACT_ENCOUNTERS(encounter_id)
);

CREATE TABLE gold.DIM_OPERATIONAL (
    encounter_id VARCHAR(100) NOT NULL PRIMARY KEY,
    physician_assessment_timestamp DATETIME2,
    bed_request_time DATETIME2,
    bed_assign_time DATETIME2,
    unit_assigned VARCHAR(50),
    bed_occupancy_pct FLOAT,
    cpt_code VARCHAR(20),
    procedure_display VARCHAR(255),
    or_start DATETIME2,
    or_end DATETIME2,
    actual_or_minutes INT,
    or_turnover_minutes INT,
    incident_type VARCHAR(50),
    incident_severity VARCHAR(20),
    pdsa_cycle_id VARCHAR(20),
    CONSTRAINT FK_OPER_ENCOUNTER FOREIGN KEY (encounter_id) REFERENCES gold.FACT_ENCOUNTERS(encounter_id)
);

CREATE TABLE gold.DIM_FINANCIAL (
    claim_id VARCHAR(20) NOT NULL PRIMARY KEY,
    encounter_id VARCHAR(100) NOT NULL,
    payer VARCHAR(50),
    npi_billing VARCHAR(10),
    drg_weight FLOAT,
    submitted_charge_usd FLOAT,
    allowed_amount_usd FLOAT,
    patient_responsibility_usd FLOAT,
    fraud_upcoding_flag TINYINT,
    fraud_duplicate_flag TINYINT,
    fraud_unbundling_flag TINYINT,
    claim_denial_flag TINYINT,
    denial_reason_code VARCHAR(10),
    equipment_type VARCHAR(50),
    equipment_usage_minutes INT,
    consumable_supply_cost_usd FLOAT,
    CONSTRAINT FK_FIN_ENCOUNTER FOREIGN KEY (encounter_id) REFERENCES gold.FACT_ENCOUNTERS(encounter_id)
);

CREATE TABLE gold.DIM_HR (
    encounter_id                    VARCHAR(100) NOT NULL PRIMARY KEY,
    nurse_emp_id                    VARCHAR(20),          -- [FIX] Required for COUNT(DISTINCT) in Q16
    nurse_role                      VARCHAR(20),
    nurse_unit                      VARCHAR(50),
    nurse_tenure_years              FLOAT,
    nurse_fte                       FLOAT,
    surgeon_emp_id                  VARCHAR(20),          -- [FIX] Required for surgeon-level reporting
    surgeon_specialty               VARCHAR(50),
    shift_hours                     INT,
    patients_per_nurse_ratio        INT,
    overtime_hours                  FLOAT,
    burnout_exhaustion_mbi          FLOAT,
    burnout_cynicism_mbi            FLOAT,
    turnover_risk_index             FLOAT,
    cahps_nurse_communication       FLOAT,
    cahps_doctor_communication      FLOAT,
    cahps_responsiveness            FLOAT,
    cahps_pain_management           FLOAT,
    cahps_discharge_info            FLOAT,
    cahps_care_transition           FLOAT,
    cahps_cleanliness               FLOAT,
    cahps_quietness                 FLOAT,
    telehealth_used_flag            TINYINT,
    appointment_request_date        DATE,
    patient_reported_wait_time_mins INT,
    CONSTRAINT FK_HR_ENCOUNTER FOREIGN KEY (encounter_id) REFERENCES gold.FACT_ENCOUNTERS(encounter_id)
);
GO

-- ============================================================
-- 3. Automated Data Loading (Distribute cleansed data from Silver to Gold)
-- ============================================================

PRINT 'Loading DIM_DATE...';
DECLARE @StartDate DATE = '2020-01-01';
DECLARE @EndDate DATE = '2030-12-31';
WHILE @StartDate <= @EndDate
BEGIN
    INSERT INTO gold.DIM_DATE VALUES (
        @StartDate,                                     -- date_key
        @StartDate,                                     -- full_date
        YEAR(@StartDate),                               -- year
        DATEPART(QUARTER,  @StartDate),                 -- quarter
        MONTH(@StartDate),                              -- month
        DATENAME(MONTH,    @StartDate),                 -- month_name
        DATEPART(WEEK,     @StartDate),                 -- week_number
        DAY(@StartDate),                                -- day_of_month
        DATEPART(WEEKDAY,  @StartDate),                 -- day_of_week
        DATENAME(WEEKDAY,  @StartDate),                 -- day_name
        CASE WHEN DATEPART(WEEKDAY, @StartDate) IN (1,7) THEN 1 ELSE 0 END  -- is_weekend
    );
    SET @StartDate = DATEADD(DAY, 1, @StartDate);
END;

PRINT 'Loading DIM_PATIENT...';
WITH RankedPatients AS (
    SELECT patient_id, birth_year, age, gender, race_ethnicity, state,
           ROW_NUMBER() OVER(PARTITION BY patient_id ORDER BY admit_timestamp DESC) as rn
    FROM silver.healthcare_cleaned
    WHERE patient_id IS NOT NULL
)
INSERT INTO gold.DIM_PATIENT
SELECT patient_id, birth_year, age, gender, race_ethnicity, state
FROM RankedPatients WHERE rn = 1;

PRINT 'Loading DIM_SUPPLY...';
WITH RankedSupply AS (
    SELECT surgical_kit_id, kit_name, kit_unit_cost_usd, kit_current_stock, 
           kit_reorder_point, kit_lead_time_days, kit_expiration_date, 
           stockout_risk_flag, weekly_procedure_volume, projected_demand_4wk, days_of_supply,
           ROW_NUMBER() OVER(PARTITION BY surgical_kit_id ORDER BY admit_timestamp DESC) as rn
    FROM silver.healthcare_cleaned
    WHERE surgical_kit_id IS NOT NULL
)
INSERT INTO gold.DIM_SUPPLY
SELECT surgical_kit_id, kit_name, kit_unit_cost_usd, kit_current_stock, 
       kit_reorder_point, kit_lead_time_days, kit_expiration_date, 
       stockout_risk_flag, weekly_procedure_volume, projected_demand_4wk, days_of_supply
FROM RankedSupply WHERE rn = 1;

PRINT 'Loading FACT_ENCOUNTERS...';
INSERT INTO gold.FACT_ENCOUNTERS
SELECT encounter_id, patient_id, claim_id, surgical_kit_id, nurse_emp_id, surgeon_emp_id, CAST(admit_timestamp AS DATE), triage_timestamp, admit_timestamp, discharge_timestamp, los_days, readmission_30d_flag, safety_incident_flag, hai_flag, follow_up_within_48h_flag, himss_emram_stage
FROM silver.healthcare_cleaned;

PRINT 'Loading DIM_CLINICAL...';
INSERT INTO gold.DIM_CLINICAL
SELECT encounter_id, icd10_code, diagnosis_display, diagnosis_category, severity_index, comorbidity_count, has_diabetes, has_hypertension, has_chf, sbp_mmhg, dbp_mmhg, heart_rate_bpm, spo2_pct, temperature_f, bmi, respiratory_rate, hba1c_pct, glucose_mg_dl, creatinine_mg_dl, wbc_10e3_ul, nt_probnp_pg_ml, medication_adherence_pdc, hedis_hba1c_tested, hedis_hba1c_poor_control
FROM silver.healthcare_cleaned;

PRINT 'Loading DIM_OPERATIONAL...';
INSERT INTO gold.DIM_OPERATIONAL
SELECT encounter_id, physician_assessment_timestamp, bed_request_time, bed_assign_time, unit_assigned, bed_occupancy_pct, cpt_code, procedure_display, or_start, or_end, actual_or_minutes, or_turnover_minutes, incident_type, incident_severity, pdsa_cycle_id
FROM silver.healthcare_cleaned;

PRINT 'Loading DIM_FINANCIAL...';
INSERT INTO gold.DIM_FINANCIAL
SELECT claim_id, encounter_id, payer, npi_billing, drg_weight, submitted_charge_usd, allowed_amount_usd, patient_responsibility_usd, fraud_upcoding_flag, fraud_duplicate_flag, fraud_unbundling_flag, claim_denial_flag, denial_reason_code, equipment_type, equipment_usage_minutes, consumable_supply_cost_usd
FROM silver.healthcare_cleaned WHERE claim_id IS NOT NULL;

PRINT 'Loading DIM_HR...';
INSERT INTO gold.DIM_HR
SELECT encounter_id, nurse_emp_id, nurse_role, nurse_unit, nurse_tenure_years, nurse_fte,
       surgeon_emp_id, surgeon_specialty, shift_hours, patients_per_nurse_ratio, overtime_hours,
       burnout_exhaustion_mbi, burnout_cynicism_mbi, turnover_risk_index,
       cahps_nurse_communication, cahps_doctor_communication, cahps_responsiveness,
       cahps_pain_management, cahps_discharge_info, cahps_care_transition,
       cahps_cleanliness, cahps_quietness,
       telehealth_used_flag, appointment_request_date, patient_reported_wait_time_mins
FROM silver.healthcare_cleaned;
GO

PRINT '✅ GOLD LAYER STAR SCHEMA CREATED AND LOADED SUCCESSFULLY!';