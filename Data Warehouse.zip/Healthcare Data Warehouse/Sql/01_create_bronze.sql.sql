/*
SCRIPT: 01_create_bronze.sql
PURPOSE: Establish the Bronze Layer to ingest raw data from the Python pipeline.
*/

USE HealthcareDB;
GO

IF OBJECT_ID(N'bronze.healthcare_raw', N'U') IS NOT NULL
    DROP TABLE bronze.healthcare_raw;
GO

CREATE TABLE bronze.healthcare_raw (
    
    -- Data Engineering Metadata Columns (Audit & Tracking)
    
    bronze_record_id BIGINT IDENTITY(1,1) PRIMARY KEY,
    batch_id UNIQUEIDENTIFIER DEFAULT NEWID(),
    loaded_at DATETIME2(6) DEFAULT SYSUTCDATETIME(),

  
    -- 1. Patient Demographics (6 Columns)
   
    patient_id NVARCHAR(MAX),
    birth_year NVARCHAR(MAX),
    age NVARCHAR(MAX),
    sex NVARCHAR(MAX),
    race_ethnicity NVARCHAR(MAX),
    state NVARCHAR(MAX),

 
    -- 2. Clinical (25 Columns)

    encounter_id NVARCHAR(MAX),
    icd10_code NVARCHAR(MAX),
    diagnosis_display NVARCHAR(MAX),
    diagnosis_category NVARCHAR(MAX),
    severity_index NVARCHAR(MAX),
    comorbidity_count NVARCHAR(MAX),
    has_diabetes NVARCHAR(MAX),
    has_hypertension NVARCHAR(MAX),
    has_chf NVARCHAR(MAX),
    sbp_mmhg NVARCHAR(MAX),
    dbp_mmhg NVARCHAR(MAX),
    heart_rate_bpm NVARCHAR(MAX),
    spo2_pct NVARCHAR(MAX),
    temperature_f NVARCHAR(MAX),
    bmi NVARCHAR(MAX),
    respiratory_rate NVARCHAR(MAX),
    hba1c_pct NVARCHAR(MAX),
    glucose_mg_dl NVARCHAR(MAX),
    creatinine_mg_dl NVARCHAR(MAX),
    wbc_10e3_ul NVARCHAR(MAX),
    nt_probnp_pg_ml NVARCHAR(MAX),
    medication_adherence_pdc NVARCHAR(MAX),
    readmission_30d_flag NVARCHAR(MAX),
    hai_flag NVARCHAR(MAX),
    follow_up_within_48h_flag NVARCHAR(MAX),

    -- 3. Operational (18 Columns)

    triage_timestamp NVARCHAR(MAX),
    physician_assessment_timestamp NVARCHAR(MAX),
    admit_timestamp NVARCHAR(MAX),
    bed_request_time NVARCHAR(MAX),
    bed_assign_time NVARCHAR(MAX),
    unit_assigned NVARCHAR(MAX),
    bed_occupancy_pct NVARCHAR(MAX),
    cpt_code NVARCHAR(MAX),
    procedure_display NVARCHAR(MAX),
    or_start NVARCHAR(MAX),
    or_end NVARCHAR(MAX),
    actual_or_minutes NVARCHAR(MAX),
    or_turnover_minutes NVARCHAR(MAX),
    los_days NVARCHAR(MAX),
    discharge_timestamp NVARCHAR(MAX),
    safety_incident_flag NVARCHAR(MAX),
    incident_type NVARCHAR(MAX),
    incident_severity NVARCHAR(MAX),

  
    -- 4. Financial (15 Columns)
 
    claim_id NVARCHAR(MAX),
    payer NVARCHAR(MAX),
    npi_billing NVARCHAR(MAX),
    drg_weight NVARCHAR(MAX),
    submitted_charge_usd NVARCHAR(MAX),
    allowed_amount_usd NVARCHAR(MAX),
    patient_responsibility_usd NVARCHAR(MAX),
    fraud_upcoding_flag NVARCHAR(MAX),
    fraud_duplicate_flag NVARCHAR(MAX),
    fraud_unbundling_flag NVARCHAR(MAX),
    claim_denial_flag NVARCHAR(MAX),
    denial_reason_code NVARCHAR(MAX),
    equipment_type NVARCHAR(MAX),
    equipment_usage_minutes NVARCHAR(MAX),
    consumable_supply_cost_usd NVARCHAR(MAX),

 
    -- 5. Human Resources (21 Columns)
 
    nurse_emp_id NVARCHAR(MAX),
    nurse_role NVARCHAR(MAX),
    nurse_unit NVARCHAR(MAX),
    nurse_tenure_years NVARCHAR(MAX),
    nurse_fte NVARCHAR(MAX),
    surgeon_emp_id NVARCHAR(MAX),
    surgeon_specialty NVARCHAR(MAX),
    shift_hours NVARCHAR(MAX),
    patients_per_nurse_ratio NVARCHAR(MAX),
    overtime_hours NVARCHAR(MAX),
    burnout_exhaustion_mbi NVARCHAR(MAX),
    burnout_cynicism_mbi NVARCHAR(MAX),
    turnover_risk_index NVARCHAR(MAX),
    cahps_nurse_communication NVARCHAR(MAX),
    cahps_doctor_communication NVARCHAR(MAX),
    cahps_responsiveness NVARCHAR(MAX),
    cahps_pain_management NVARCHAR(MAX),
    cahps_discharge_info NVARCHAR(MAX),
    cahps_care_transition NVARCHAR(MAX),
    cahps_cleanliness NVARCHAR(MAX),
    cahps_quietness NVARCHAR(MAX),


    -- 6. Patient Experience (3 Columns)
   
    telehealth_used_flag NVARCHAR(MAX),
    appointment_request_date NVARCHAR(MAX),
    patient_reported_wait_time_mins NVARCHAR(MAX),

   
    -- 7. Supply Chain (11 Columns)
    
    surgical_kit_id NVARCHAR(MAX),
    kit_name NVARCHAR(MAX),
    kit_unit_cost_usd NVARCHAR(MAX),
    kit_current_stock NVARCHAR(MAX),
    kit_reorder_point NVARCHAR(MAX),
    kit_lead_time_days NVARCHAR(MAX),
    kit_expiration_date NVARCHAR(MAX),
    stockout_risk_flag NVARCHAR(MAX),
    weekly_procedure_volume NVARCHAR(MAX),
    projected_demand_4wk NVARCHAR(MAX),
    days_of_supply NVARCHAR(MAX),

  
    -- 8. Quality and Standards (4 Columns)
    
    hedis_hba1c_tested NVARCHAR(MAX),
    hedis_hba1c_poor_control NVARCHAR(MAX),
    pdsa_cycle_id NVARCHAR(MAX),
    himss_emram_stage NVARCHAR(MAX)
);
GO