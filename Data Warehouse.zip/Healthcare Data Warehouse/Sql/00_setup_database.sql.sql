/*
SCRIPT  : 00_setup_database.sql
PURPOSE : Initialize the Healthcare project database and establish the three core schemas (Medallion Architecture).
*/

USE master;
GO

-- 2. Create the Healthcare database
IF DB_ID(N'HealthcareDB') IS NULL
BEGIN
    CREATE DATABASE HealthcareDB;
END;
GO


USE HealthcareDB;
GO

-- 4. Create the Medallion Architecture schemas (bronze, silver, gold)
IF SCHEMA_ID(N'bronze') IS NULL
    EXEC(N'CREATE SCHEMA bronze');
GO

IF SCHEMA_ID(N'silver') IS NULL
    EXEC(N'CREATE SCHEMA silver');
GO

IF SCHEMA_ID(N'gold') IS NULL
    EXEC(N'CREATE SCHEMA gold');
GO