/*
================================================================================
SCRIPT  : 02_create_and_load_silver.sql
PURPOSE : Clean and transform data from Bronze to Silver layer
          Full translation of final_project_depi_v2.py → SQL
DATASET : encounters_v2.csv  (103 columns — HIPAA Safe Harbor)
SECTIONS:
    1. Drop & Create silver.healthcare_cleaned
    2. INSERT with full transformation (103 columns)
       5.1  DateTime columns      (8 cols)
       5.2  Date columns          (2 cols)
       5.3  String ID columns     (2 cols — npi_billing zfill, cpt_code)
       5.4  Float columns         (35 cols)
       5.5  Integer columns       (17 cols)
       5.6  Strip whitespace      (all string cols — done inline via TRIM)
       6.   Binary validation     (15 cols — validated via CHECK constraints)
       7.   Range validation      (31 ranges — reported via a QA view)
       8.   Timestamp logic fix   (physician_assessment ↔ admit_timestamp SWAP)
NOTE    : No imputation — NULLs stay as-is (structural by design).
          No calculated/derived columns — handled in Power BI.
================================================================================
*/

USE HealthcareDB;
GO

-- ============================================================
-- SECTION 1 — Drop old table & Create silver.healthcare_cleaned
-- ============================================================
IF OBJECT_ID(N'silver.healthcare_cleaned', N'U') IS NOT NULL
    DROP TABLE silver.healthcare_cleaned;
GO

CREATE TABLE silver.healthcare_cleaned (

    -- ── Patient Demographics ─────────────────────────────────
    patient_id                      VARCHAR(20),
    birth_year                      INT,
    age                             INT,
    gender                          VARCHAR(10),
    race_ethnicity                  VARCHAR(50),
    state                           CHAR(2),

    -- ── Clinical ─────────────────────────────────────────────
    encounter_id                    VARCHAR(100)    NOT NULL PRIMARY KEY,
    icd10_code                      VARCHAR(10),
    diagnosis_display               VARCHAR(255),
    diagnosis_category              VARCHAR(20),
    severity_index                  FLOAT,
    comorbidity_count               INT,
    has_diabetes                    TINYINT CHECK (has_diabetes IN (0,1)),       -- Binary 0/1
    has_hypertension                TINYINT CHECK (has_hypertension IN (0,1)),        -- Binary 0/1
    has_chf                         TINYINT CHECK (has_chf IN (0,1)),                    -- Binary 0/1
    sbp_mmhg                        FLOAT,
    dbp_mmhg                        FLOAT,
    heart_rate_bpm                  FLOAT,
    spo2_pct                        FLOAT,
    temperature_f                   FLOAT,
    bmi                             FLOAT,
    respiratory_rate                INT,
    hba1c_pct                       FLOAT,
    glucose_mg_dl                   FLOAT,
    creatinine_mg_dl                FLOAT,
    wbc_10e3_ul                     FLOAT,
    nt_probnp_pg_ml                 FLOAT,
    medication_adherence_pdc        FLOAT,
    readmission_30d_flag           TINYINT CHECK (readmission_30d_flag IN (0,1)),        -- Binary 0/1
    hai_flag                        TINYINT CHECK (hai_flag IN (0,1)),        -- Binary 0/1
    follow_up_within_48h_flag       TINYINT CHECK (follow_up_within_48h_flag IN (0,1)),        -- Binary 0/1

    -- ── Operational ──────────────────────────────────────────
    triage_timestamp                DATETIME2,
    physician_assessment_timestamp  DATETIME2,
    admit_timestamp                 DATETIME2,
    bed_request_time                DATETIME2,
    bed_assign_time                 DATETIME2,
    unit_assigned                   VARCHAR(50),
    bed_occupancy_pct               FLOAT,
    cpt_code                        VARCHAR(20),
    procedure_display               VARCHAR(255),
    or_start                        DATETIME2,
    or_end                          DATETIME2,
    actual_or_minutes               INT,
    or_turnover_minutes             INT,
    los_days                        INT,
    discharge_timestamp             DATETIME2,
    safety_incident_flag            TINYINT CHECK (safety_incident_flag  IN (0,1)),        -- Binary 0/1
    incident_type                   VARCHAR(50),
    incident_severity               VARCHAR(20),

    -- ── Financial ────────────────────────────────────────────
    claim_id                        VARCHAR(20),
    payer                           VARCHAR(50),
    npi_billing                     VARCHAR(10),    -- zero-padded to 10 digits
    drg_weight                      FLOAT,
   submitted_charge_usd            DECIMAL(10,2),
    allowed_amount_usd              DECIMAL(10,2),
    patient_responsibility_usd      DECIMAL(10,2),
    fraud_upcoding_flag             TINYINT CHECK (fraud_upcoding_flag IN (0,1)),        -- Binary 0/1
    fraud_duplicate_flag            TINYINT CHECK (fraud_duplicate_flag IN (0,1)),        -- Binary 0/1
    fraud_unbundling_flag           TINYINT CHECK (fraud_unbundling_flag IN (0,1)),        -- Binary 0/1
    claim_denial_flag               TINYINT CHECK (claim_denial_flag IN (0,1)),        -- Binary 0/1
    denial_reason_code              VARCHAR(10),
    equipment_type                  VARCHAR(50),
    equipment_usage_minutes         INT,
    consumable_supply_cost_usd      DECIMAL(10,2),

    -- ── Human Resources ──────────────────────────────────────
    nurse_emp_id                    VARCHAR(20),
    nurse_role                      VARCHAR(20),
    nurse_unit                      VARCHAR(50),
    nurse_tenure_years              FLOAT,
    nurse_fte                       FLOAT,
    surgeon_emp_id                  VARCHAR(20),
    surgeon_specialty               VARCHAR(50),
    shift_hours                     INT,
    patients_per_nurse_ratio        INT,
    overtime_hours                  FLOAT,
    burnout_exhaustion_mbi          FLOAT,
    burnout_cynicism_mbi            FLOAT,
    turnover_risk_index             FLOAT,
    cahps_nurse_communication       FLOAT,
    cahps_doctor_communication      FLOAT,
    cahps_responsiveness            FLOAT,
    cahps_pain_management           FLOAT,
    cahps_discharge_info            FLOAT,
    cahps_care_transition           FLOAT,
    cahps_cleanliness               FLOAT,
    cahps_quietness                 FLOAT,

    -- ── Patient Experience & Engagement ──────────────────────
    telehealth_used_flag            TINYINT CHECK (telehealth_used_flag IN (0,1)),        -- Binary 0/1
    appointment_request_date        DATE,
    patient_reported_wait_time_mins INT,

    -- ── Supply Chain ─────────────────────────────────────────
    surgical_kit_id                 VARCHAR(20),
    kit_name                        VARCHAR(50),
    kit_unit_cost_usd               FLOAT,
    kit_current_stock               INT,
    kit_reorder_point               INT,
    kit_lead_time_days              INT,
    kit_expiration_date             DATE,
    stockout_risk_flag              TINYINT CHECK (stockout_risk_flag IN (0,1)),        -- Binary 0/1
    weekly_procedure_volume         INT,
    projected_demand_4wk            INT,
    days_of_supply                  FLOAT,

    -- ── Quality & Standards ──────────────────────────────────
    hedis_hba1c_tested              TINYINT CHECK (hedis_hba1c_tested IN (0,1)),        -- Binary 0/1
    hedis_hba1c_poor_control        TINYINT CHECK (hedis_hba1c_poor_control IN (0,1)),        -- Binary 0/1
    pdsa_cycle_id                   VARCHAR(20),
    himss_emram_stage               INT,

    -- ── Metadata ─────────────────────────────────────────────
    meta_cleaned_at                 DATETIME2 DEFAULT SYSUTCDATETIME()
);
GO

-- ============================================================
-- SECTION 2 — INSERT with Full Transformation (103 columns)
-- ============================================================
PRINT 'Starting Data Transformation to Silver Layer...';

INSERT INTO silver.healthcare_cleaned (

    -- Patient Demographics
    patient_id, birth_year, age, gender, race_ethnicity, state,

    -- Clinical
    encounter_id, icd10_code, diagnosis_display, diagnosis_category,
    severity_index, comorbidity_count,
    has_diabetes, has_hypertension, has_chf,
    sbp_mmhg, dbp_mmhg, heart_rate_bpm, spo2_pct, temperature_f, bmi,
    respiratory_rate, hba1c_pct, glucose_mg_dl, creatinine_mg_dl,
    wbc_10e3_ul, nt_probnp_pg_ml, medication_adherence_pdc,
    readmission_30d_flag, hai_flag, follow_up_within_48h_flag,

    -- Operational
    triage_timestamp, physician_assessment_timestamp, admit_timestamp,
    bed_request_time, bed_assign_time,
    unit_assigned, bed_occupancy_pct, cpt_code, procedure_display,
    or_start, or_end, actual_or_minutes, or_turnover_minutes,
    los_days, discharge_timestamp,
    safety_incident_flag, incident_type, incident_severity,

    -- Financial
    claim_id, payer, npi_billing, drg_weight,
    submitted_charge_usd, allowed_amount_usd, patient_responsibility_usd,
    fraud_upcoding_flag, fraud_duplicate_flag, fraud_unbundling_flag,
    claim_denial_flag, denial_reason_code,
    equipment_type, equipment_usage_minutes, consumable_supply_cost_usd,

    -- HR
    nurse_emp_id, nurse_role, nurse_unit, nurse_tenure_years, nurse_fte,
    surgeon_emp_id, surgeon_specialty,
    shift_hours, patients_per_nurse_ratio, overtime_hours,
    burnout_exhaustion_mbi, burnout_cynicism_mbi, turnover_risk_index,
    cahps_nurse_communication, cahps_doctor_communication,
    cahps_responsiveness, cahps_pain_management, cahps_discharge_info,
    cahps_care_transition, cahps_cleanliness, cahps_quietness,

    -- Patient Experience & Engagement
    telehealth_used_flag, appointment_request_date,
    patient_reported_wait_time_mins,

    -- Supply Chain
    surgical_kit_id, kit_name, kit_unit_cost_usd,
    kit_current_stock, kit_reorder_point, kit_lead_time_days,
    kit_expiration_date, stockout_risk_flag,
    weekly_procedure_volume, projected_demand_4wk, days_of_supply,

    -- Quality & Standards
    hedis_hba1c_tested, hedis_hba1c_poor_control,
    pdsa_cycle_id, himss_emram_stage
)

SELECT

    -- ══════════════════════════════════════════════════════════
    -- SECTION 5.6 — TRIM all Strings + Type Conversions
    -- ══════════════════════════════════════════════════════════

    -- ── Patient Demographics ─────────────────────────────────
    -- [5.6] TRIM strings  |  [5.5] INT
    TRIM(patient_id)                                        AS patient_id,
    TRY_CONVERT(INT,   TRIM(birth_year))                    AS birth_year,
    TRY_CONVERT(INT,   TRIM(age))                           AS age,
    TRIM(sex)                                               AS gender,         -- RAW column name is sex
    TRIM(race_ethnicity)                                    AS race_ethnicity,
    TRIM(state)                                             AS state,

    -- ── Clinical ─────────────────────────────────────────────
    TRIM(encounter_id)                                      AS encounter_id,
    TRIM(icd10_code)                                        AS icd10_code,
    TRIM(diagnosis_display)                                 AS diagnosis_display,
    TRIM(diagnosis_category)                                AS diagnosis_category,

    -- [5.4] FLOAT
    TRY_CONVERT(FLOAT, TRIM(severity_index))                AS severity_index,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(comorbidity_count))             AS comorbidity_count,

    -- [6.] Binary — TINYINT (0/1 only)
    TRY_CONVERT(TINYINT, TRIM(has_diabetes))                AS has_diabetes,
    TRY_CONVERT(TINYINT, TRIM(has_hypertension))            AS has_hypertension,
    TRY_CONVERT(TINYINT, TRIM(has_chf))                     AS has_chf,

    -- [5.4] FLOAT — Vitals
    TRY_CONVERT(FLOAT, TRIM(sbp_mmhg))                      AS sbp_mmhg,
    TRY_CONVERT(FLOAT, TRIM(dbp_mmhg))                      AS dbp_mmhg,
    TRY_CONVERT(FLOAT, TRIM(heart_rate_bpm))                AS heart_rate_bpm,
    TRY_CONVERT(FLOAT, TRIM(spo2_pct))                      AS spo2_pct,
    TRY_CONVERT(FLOAT, TRIM(temperature_f))                 AS temperature_f,
    TRY_CONVERT(FLOAT, TRIM(bmi))                           AS bmi,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(respiratory_rate))              AS respiratory_rate,

    -- [5.4] FLOAT — Labs
    TRY_CONVERT(FLOAT, TRIM(hba1c_pct))                     AS hba1c_pct,
    TRY_CONVERT(FLOAT, TRIM(glucose_mg_dl))                 AS glucose_mg_dl,
    TRY_CONVERT(FLOAT, TRIM(creatinine_mg_dl))              AS creatinine_mg_dl,
    TRY_CONVERT(FLOAT, TRIM(wbc_10e3_ul))                   AS wbc_10e3_ul,
    TRY_CONVERT(FLOAT, TRIM(nt_probnp_pg_ml))               AS nt_probnp_pg_ml,
    TRY_CONVERT(FLOAT, TRIM(medication_adherence_pdc))      AS medication_adherence_pdc,

    -- [6.] Binary
    TRY_CONVERT(TINYINT, TRIM(readmission_30d_flag))        AS readmission_30d_flag,
    TRY_CONVERT(TINYINT, TRIM(hai_flag))                    AS hai_flag,
    TRY_CONVERT(TINYINT, TRIM(follow_up_within_48h_flag))   AS follow_up_within_48h_flag,

    -- ── Operational — Timestamps ─────────────────────────────
    -- [5.1] DateTime (TRY_CONVERT instead of pd.to_datetime errors='coerce')

    -- triage_timestamp — stays as-is, no swap applied
    TRY_CONVERT(DATETIME2, TRIM(triage_timestamp))          AS triage_timestamp,

    -- ══════════════════════════════════════════════════════════
    -- SECTION 8 — Timestamp Logic Fix (THE SWAP)
    -- Rule: physician_assessment must always come before admit_timestamp
    -- If admit < physician_assessment → swap the two values
    -- Exactly like Python:
    --   temp = df.loc[mask, "admit_timestamp"]
    --   df.loc[mask, "admit_timestamp"] = df.loc[mask, "physician_assessment_timestamp"]
    --   df.loc[mask, "physician_assessment_timestamp"] = temp
    -- ══════════════════════════════════════════════════════════

    -- physician_assessment_timestamp after SWAP
    CASE
        WHEN TRY_CONVERT(DATETIME2, TRIM(admit_timestamp))
             < TRY_CONVERT(DATETIME2, TRIM(physician_assessment_timestamp))
        -- violation → assign the earlier (smaller) admit value to physician
        THEN TRY_CONVERT(DATETIME2, TRIM(admit_timestamp))
        -- no violation → keep as-is
        ELSE TRY_CONVERT(DATETIME2, TRIM(physician_assessment_timestamp))
    END                                                     AS physician_assessment_timestamp,

    -- admit_timestamp after SWAP
    CASE
        WHEN TRY_CONVERT(DATETIME2, TRIM(admit_timestamp))
             < TRY_CONVERT(DATETIME2, TRIM(physician_assessment_timestamp))
        -- violation → assign the larger physician_assessment value to admit
        THEN TRY_CONVERT(DATETIME2, TRIM(physician_assessment_timestamp))
        -- no violation → keep as-is
        ELSE TRY_CONVERT(DATETIME2, TRIM(admit_timestamp))
    END                                                     AS admit_timestamp,

    -- Remaining DateTime columns [5.1] — no swap applied
    TRY_CONVERT(DATETIME2, TRIM(bed_request_time))          AS bed_request_time,
    TRY_CONVERT(DATETIME2, TRIM(bed_assign_time))           AS bed_assign_time,

    -- ── Operational — Strings & Numbers ──────────────────────
    TRIM(unit_assigned)                                     AS unit_assigned,
    TRY_CONVERT(FLOAT,   TRIM(bed_occupancy_pct))           AS bed_occupancy_pct,

    -- [5.3] cpt_code → String only (not zero-padded)
    TRIM(CAST(cpt_code AS VARCHAR(20)))                     AS cpt_code,

    TRIM(procedure_display)                                 AS procedure_display,

    -- [5.1] DateTime
    TRY_CONVERT(DATETIME2, TRIM(or_start))                  AS or_start,
    TRY_CONVERT(DATETIME2, TRIM(or_end))                    AS or_end,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(actual_or_minutes))             AS actual_or_minutes,
    TRY_CONVERT(INT,   TRIM(or_turnover_minutes))           AS or_turnover_minutes,
    TRY_CONVERT(INT,   TRIM(los_days))                      AS los_days,

    -- [5.1] DateTime
    TRY_CONVERT(DATETIME2, TRIM(discharge_timestamp))       AS discharge_timestamp,

    -- [6.] Binary
    TRY_CONVERT(TINYINT, TRIM(safety_incident_flag))        AS safety_incident_flag,

    -- [5.6] TRIM strings
    TRIM(incident_type)                                     AS incident_type,
    TRIM(incident_severity)                                 AS incident_severity,

    -- ── Financial ─────────────────────────────────────────────
    TRIM(claim_id)                                          AS claim_id,
    TRIM(payer)                                             AS payer,

    -- [5.3] npi_billing → zero-pad to 10 digits (like str.zfill(10))
    RIGHT('0000000000' + TRIM(CAST(npi_billing AS VARCHAR(20))), 10)
                                                            AS npi_billing,

    -- [5.4] FLOAT
    TRY_CONVERT(FLOAT, TRIM(drg_weight))                    AS drg_weight,
    -- Decimal
    TRY_CONVERT(DECIMAL(10,2), TRIM(submitted_charge_usd))          AS submitted_charge_usd,
   TRY_CONVERT(DECIMAL(10,2), TRIM(allowed_amount_usd))            AS allowed_amount_usd,
    TRY_CONVERT(DECIMAL(10,2), TRIM(patient_responsibility_usd))    AS patient_responsibility_usd,

    -- [6.] Binary
    TRY_CONVERT(TINYINT, TRIM(fraud_upcoding_flag))         AS fraud_upcoding_flag,
    TRY_CONVERT(TINYINT, TRIM(fraud_duplicate_flag))        AS fraud_duplicate_flag,
    TRY_CONVERT(TINYINT, TRIM(fraud_unbundling_flag))       AS fraud_unbundling_flag,
    TRY_CONVERT(TINYINT, TRIM(claim_denial_flag))           AS claim_denial_flag,

    -- [5.6] TRIM strings
    TRIM(denial_reason_code)                                AS denial_reason_code,
    TRIM(equipment_type)                                    AS equipment_type,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(equipment_usage_minutes))       AS equipment_usage_minutes,

    -- Descimal
    TRY_CONVERT(DECIMAL(10,2), TRIM(consumable_supply_cost_usd))    AS consumable_supply_cost_usd,

    -- ── Human Resources ──────────────────────────────────────
    TRIM(nurse_emp_id)                                      AS nurse_emp_id,
    TRIM(nurse_role)                                        AS nurse_role,
    TRIM(nurse_unit)                                        AS nurse_unit,

    -- [5.4] FLOAT
    TRY_CONVERT(FLOAT, TRIM(nurse_tenure_years))            AS nurse_tenure_years,
    TRY_CONVERT(FLOAT, TRIM(nurse_fte))                     AS nurse_fte,

    TRIM(surgeon_emp_id)                                    AS surgeon_emp_id,
    TRIM(surgeon_specialty)                                 AS surgeon_specialty,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(shift_hours))                   AS shift_hours,
    TRY_CONVERT(INT,   TRIM(patients_per_nurse_ratio))      AS patients_per_nurse_ratio,

    -- [5.4] FLOAT
    TRY_CONVERT(FLOAT, TRIM(overtime_hours))                AS overtime_hours,
    TRY_CONVERT(FLOAT, TRIM(burnout_exhaustion_mbi))        AS burnout_exhaustion_mbi,
    TRY_CONVERT(FLOAT, TRIM(burnout_cynicism_mbi))          AS burnout_cynicism_mbi,
    TRY_CONVERT(FLOAT, TRIM(turnover_risk_index))           AS turnover_risk_index,

    -- [5.4] FLOAT — CAHPS scores
    TRY_CONVERT(FLOAT, TRIM(cahps_nurse_communication))     AS cahps_nurse_communication,
    TRY_CONVERT(FLOAT, TRIM(cahps_doctor_communication))    AS cahps_doctor_communication,
    TRY_CONVERT(FLOAT, TRIM(cahps_responsiveness))          AS cahps_responsiveness,
    TRY_CONVERT(FLOAT, TRIM(cahps_pain_management))         AS cahps_pain_management,
    TRY_CONVERT(FLOAT, TRIM(cahps_discharge_info))          AS cahps_discharge_info,
    TRY_CONVERT(FLOAT, TRIM(cahps_care_transition))         AS cahps_care_transition,
    TRY_CONVERT(FLOAT, TRIM(cahps_cleanliness))             AS cahps_cleanliness,
    TRY_CONVERT(FLOAT, TRIM(cahps_quietness))               AS cahps_quietness,

    -- ── Patient Experience & Engagement ──────────────────────
    -- [6.] Binary
    TRY_CONVERT(TINYINT, TRIM(telehealth_used_flag))        AS telehealth_used_flag,

    -- [5.2] Date (instead of pd.to_datetime().dt.date)
    TRY_CONVERT(DATE, TRIM(appointment_request_date))       AS appointment_request_date,

    -- [5.5] INT
    TRY_CONVERT(INT, TRIM(patient_reported_wait_time_mins)) AS patient_reported_wait_time_mins,

    -- ── Supply Chain ──────────────────────────────────────────
    TRIM(surgical_kit_id)                                   AS surgical_kit_id,
    TRIM(kit_name)                                          AS kit_name,

    -- [5.4] FLOAT
    TRY_CONVERT(FLOAT, TRIM(kit_unit_cost_usd))             AS kit_unit_cost_usd,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(kit_current_stock))             AS kit_current_stock,
    TRY_CONVERT(INT,   TRIM(kit_reorder_point))             AS kit_reorder_point,
    TRY_CONVERT(INT,   TRIM(kit_lead_time_days))            AS kit_lead_time_days,

    -- [5.2] Date
    TRY_CONVERT(DATE, TRIM(kit_expiration_date))            AS kit_expiration_date,

    -- [6.] Binary
    TRY_CONVERT(TINYINT, TRIM(stockout_risk_flag))          AS stockout_risk_flag,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(weekly_procedure_volume))       AS weekly_procedure_volume,
    TRY_CONVERT(INT,   TRIM(projected_demand_4wk))          AS projected_demand_4wk,

    -- [5.4] FLOAT
    TRY_CONVERT(FLOAT, TRIM(days_of_supply))                AS days_of_supply,

    -- ── Quality & Standards ──────────────────────────────────
    -- [6.] Binary
    TRY_CONVERT(TINYINT, TRIM(hedis_hba1c_tested))          AS hedis_hba1c_tested,
    TRY_CONVERT(TINYINT, TRIM(hedis_hba1c_poor_control))    AS hedis_hba1c_poor_control,

    -- [5.6] TRIM string
    TRIM(pdsa_cycle_id)                                     AS pdsa_cycle_id,

    -- [5.5] INT
    TRY_CONVERT(INT,   TRIM(himss_emram_stage))             AS himss_emram_stage

FROM bronze.healthcare_raw
WHERE TRIM(encounter_id) IS NOT NULL;   -- Guard against empty rows (like dropna in Python)
GO

PRINT '✅ Silver Layer Loaded Successfully!';
GO

-- ============================================================
-- SECTION 7 — Range Validation QA View (Report Only — No Fix)
-- Replaces Section 7 in Python:
--   "Per instructor: blanks and out-of-range values are
--    reported only. No values are replaced or removed."
-- ============================================================
IF OBJECT_ID(N'silver.vw_range_validation_report', N'V') IS NOT NULL
    DROP VIEW silver.vw_range_validation_report;
GO

CREATE VIEW silver.vw_range_validation_report AS
/*
    Each row = a column that has values outside the allowed range.
    If the view is empty → ✅ all columns are within the correct range.
    If there are rows → ℹ️ report only, do not modify (per instructor).
*/
SELECT col_name, valid_min, valid_max, out_of_range_count, description
FROM (
    SELECT 'age' AS col_name, '0' AS valid_min, '95' AS valid_max, (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE age < 0 OR age > 95) AS out_of_range_count, 'HIPAA cap' AS description
    UNION ALL
    SELECT 'severity_index', '0.0', '1.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE severity_index < 0.0 OR severity_index > 1.0), 'Synthetic acuity score'
    UNION ALL
    SELECT 'medication_adherence_pdc', '0.0', '1.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE medication_adherence_pdc < 0.0 OR medication_adherence_pdc > 1.0), 'Proportion of Days Covered'
    UNION ALL
    SELECT 'sbp_mmhg', '60', '220', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE sbp_mmhg < 60 OR sbp_mmhg > 220), 'Systolic blood pressure'
    UNION ALL
    SELECT 'dbp_mmhg', '40', '140', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE dbp_mmhg < 40 OR dbp_mmhg > 140), 'Diastolic blood pressure'
    UNION ALL
    SELECT 'heart_rate_bpm', '30', '200', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE heart_rate_bpm < 30 OR heart_rate_bpm > 200), 'Heart rate'
    UNION ALL
    SELECT 'spo2_pct', '70', '100', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE spo2_pct < 70 OR spo2_pct > 100), 'Oxygen saturation'
    UNION ALL
    SELECT 'temperature_f', '94', '106', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE temperature_f < 94 OR temperature_f > 106), 'Body temperature'
    UNION ALL
    SELECT 'bmi', '10', '70', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE bmi < 10 OR bmi > 70), 'Body mass index'
    UNION ALL
    SELECT 'hba1c_pct', '4.0', '15.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE hba1c_pct < 4.0 OR hba1c_pct > 15.0), 'Hemoglobin A1c'
    UNION ALL
    SELECT 'glucose_mg_dl', '40', '600', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE glucose_mg_dl < 40 OR glucose_mg_dl > 600), 'Serum glucose'
    UNION ALL
    SELECT 'creatinine_mg_dl', '0.1', '15.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE creatinine_mg_dl < 0.1 OR creatinine_mg_dl > 15.0), 'Serum creatinine'
    UNION ALL
    SELECT 'wbc_10e3_ul', '0.5', '50.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE wbc_10e3_ul < 0.5 OR wbc_10e3_ul > 50.0), 'White blood cell count'
    UNION ALL
    SELECT 'los_days', '0', '60', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE los_days < 0 OR los_days > 60), 'Length of stay'
    UNION ALL
    SELECT 'bed_occupancy_pct', '0', '100', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE bed_occupancy_pct < 0 OR bed_occupancy_pct > 100), 'Bed occupancy'
    UNION ALL
    SELECT 'burnout_exhaustion_mbi', '0.0', '6.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE burnout_exhaustion_mbi < 0.0 OR burnout_exhaustion_mbi > 6.0), 'MBI Exhaustion [0-6]'
    UNION ALL
    SELECT 'burnout_cynicism_mbi', '0.0', '6.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE burnout_cynicism_mbi < 0.0 OR burnout_cynicism_mbi > 6.0), 'MBI Cynicism [0-6]'
    UNION ALL
    SELECT 'turnover_risk_index', '0.0', '1.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE turnover_risk_index < 0.0 OR turnover_risk_index > 1.0), 'Turnover risk [0-1]'
    UNION ALL
    SELECT 'himss_emram_stage', '0', '7', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE himss_emram_stage < 0 OR himss_emram_stage > 7), 'HIMSS EMRAM [0-7]'
    UNION ALL
    SELECT 'drg_weight', '0.1', '10.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE drg_weight < 0.1 OR drg_weight > 10.0), 'DRG weight'
    UNION ALL
    SELECT 'nurse_fte', '0.0', '1.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE nurse_fte < 0.0 OR nurse_fte > 1.0), 'Nurse FTE [0-1]'
    UNION ALL
    SELECT 'shift_hours', '8', '12', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE shift_hours < 8 OR shift_hours > 12), 'Shift hours [8,10,12]'
    UNION ALL
    SELECT 'patients_per_nurse_ratio', '1', '20', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE patients_per_nurse_ratio < 1 OR patients_per_nurse_ratio > 20), 'Patients per nurse'
    UNION ALL
    SELECT 'cahps_nurse_communication', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_nurse_communication < 1.0 OR cahps_nurse_communication > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_doctor_communication', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_doctor_communication < 1.0 OR cahps_doctor_communication > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_responsiveness', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_responsiveness < 1.0 OR cahps_responsiveness > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_pain_management', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_pain_management < 1.0 OR cahps_pain_management > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_discharge_info', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_discharge_info < 1.0 OR cahps_discharge_info > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_care_transition', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_care_transition < 1.0 OR cahps_care_transition > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_cleanliness', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_cleanliness < 1.0 OR cahps_cleanliness > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'cahps_quietness', '1.0', '5.0', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE cahps_quietness < 1.0 OR cahps_quietness > 5.0), 'CAHPS score [1-5]'
    UNION ALL
    SELECT 'days_of_supply', '0', '365', (SELECT COUNT(*) FROM silver.healthcare_cleaned WHERE days_of_supply < 0 OR days_of_supply > 365), 'Days of supply'
) AS t
WHERE out_of_range_count > 0;
GO

-- Operational query for the report (Section 7 equivalent)
-- SELECT * FROM silver.vw_range_validation_report ORDER BY col_name;
PRINT '✅ Range Validation View Created: silver.vw_range_validation_report';
GO
-- ============================================================
-- SECTION 8 — Timestamp Logic Check (Verification After Load)
-- Replaces the Additional Timestamp Checks in Python (report only)
-- ============================================================
PRINT '';
PRINT '=== Timestamp Order Checks (Report Only) ===';

SELECT
    'triage → physician_assessment'             AS check_name,
    'triage_timestamp must be BEFORE physician_assessment_timestamp' AS validation_rule,
    SUM(CASE WHEN physician_assessment_timestamp < triage_timestamp THEN 1 ELSE 0 END) AS violations
FROM silver.healthcare_cleaned

UNION ALL

SELECT
    'bed_request → bed_assign',
    'bed_request_time must be BEFORE bed_assign_time',
    SUM(CASE WHEN bed_assign_time < bed_request_time THEN 1 ELSE 0 END)
FROM silver.healthcare_cleaned

UNION ALL

SELECT
    'or_start → or_end',
    'OR start must be BEFORE OR end',
    SUM(CASE WHEN or_end < or_start THEN 1 ELSE 0 END)
FROM silver.healthcare_cleaned

UNION ALL

SELECT
    'admit → discharge',
    'admission must be BEFORE discharge',
    SUM(CASE WHEN discharge_timestamp < admit_timestamp THEN 1 ELSE 0 END)
FROM silver.healthcare_cleaned

UNION ALL

SELECT
    'physician_assessment → admit (POST-SWAP)',
    'physician_assessment must be BEFORE admit (should be 0 after swap)',
    SUM(CASE WHEN admit_timestamp < physician_assessment_timestamp THEN 1 ELSE 0 END)
FROM silver.healthcare_cleaned;
GO




-- ============================================================
-- SECTION 9 — Final Summary (replaces Section 11 in Python)
-- ============================================================
PRINT '';
PRINT '========================================';
PRINT '   SILVER LAYER — FINAL SUMMARY';
PRINT '========================================';

SELECT
    COUNT(*)                                                AS total_rows,
    103                                                     AS total_columns,
    SUM(CASE WHEN encounter_id IS NULL THEN 1 ELSE 0 END)   AS null_encounter_ids,
    MIN(meta_cleaned_at)                                    AS load_started_at,
    MAX(meta_cleaned_at)                                    AS load_ended_at
FROM silver.healthcare_cleaned;
GO

PRINT '✅ DONE — Silver Layer is clean and ready for Gold & Power BI.';
GO
-- Verification query only (does not affect data)
SELECT
    'triage → physician_assessment'             AS check_name,
    'triage_timestamp must be BEFORE physician_assessment_timestamp' AS validation_rule,
    SUM(CASE WHEN physician_assessment_timestamp < triage_timestamp THEN 1 ELSE 0 END) AS violations
FROM HealthcareDB.silver.healthcare_cleaned
UNION ALL
SELECT
    'bed_request → bed_assign',
    'bed_request_time must be BEFORE bed_assign_time',
    SUM(CASE WHEN bed_assign_time < bed_request_time THEN 1 ELSE 0 END)
FROM HealthcareDB.silver.healthcare_cleaned
UNION ALL
SELECT
    'or_start → or_end',
    'OR start must be BEFORE OR end',
    SUM(CASE WHEN or_end < or_start THEN 1 ELSE 0 END)
FROM HealthcareDB.silver.healthcare_cleaned
UNION ALL
SELECT
    'admit → discharge',
    'admission must be BEFORE discharge',
    SUM(CASE WHEN discharge_timestamp < admit_timestamp THEN 1 ELSE 0 END)
FROM HealthcareDB.silver.healthcare_cleaned
UNION ALL
SELECT
    'physician_assessment → admit (POST-SWAP)',
    'physician_assessment must be BEFORE admit (should be 0 after swap)',
    SUM(CASE WHEN admit_timestamp < physician_assessment_timestamp THEN 1 ELSE 0 END)
FROM HealthcareDB.silver.healthcare_cleaned;