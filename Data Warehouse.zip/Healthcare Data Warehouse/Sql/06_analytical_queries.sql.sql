/*
================================================================================
SCRIPT  : 07_analytical_queries.sql
PURPOSE : 20 Analytical queries to answer business questions and feed reporting dashboards.
================================================================================
*/

USE HealthcareDB;
GO

-- ============================================================
-- Q1: Monthly Encounter Volume (MoM Trend)
-- ============================================================
SELECT
    d.year, d.month, d.month_name,
    COUNT(f.encounter_id) AS total_encounters,
    LAG(COUNT(f.encounter_id)) OVER(ORDER BY d.year, d.month) AS prev_month_encounters,
    ROUND((COUNT(f.encounter_id) - LAG(COUNT(f.encounter_id)) OVER (ORDER BY d.year, d.month)) * 100.0 
    / NULLIF(LAG(COUNT(f.encounter_id)) OVER (ORDER BY d.year, d.month), 0), 2) AS mom_growth_pct
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_DATE d ON f.admit_date_key = d.date_key
GROUP BY d.year, d.month, d.month_name
ORDER BY d.year, d.month;
GO

-- ============================================================
-- Q2: Readmission Rate by Diagnosis Category
-- ============================================================
SELECT
    c.diagnosis_category,
    COUNT(f.encounter_id) AS total_encounters,
    SUM(CAST(f.readmission_30d_flag AS INT)) AS readmitted,
    ROUND(SUM(CAST(f.readmission_30d_flag AS FLOAT)) / COUNT(f.encounter_id) * 100, 2) AS readmission_rate_pct,
    ROUND(AVG(c.severity_index), 3) AS avg_severity
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_CLINICAL c ON f.encounter_id = c.encounter_id
GROUP BY c.diagnosis_category
ORDER BY readmission_rate_pct DESC;
GO

-- ============================================================
-- Q3: Revenue Analysis by Payer
-- ============================================================
SELECT
    fin.payer,
    COUNT(fin.claim_id) AS total_claims,
    ROUND(SUM(fin.submitted_charge_usd), 2) AS total_submitted,
    ROUND(SUM(fin.allowed_amount_usd), 2) AS total_allowed,
    ROUND(SUM(fin.patient_responsibility_usd), 2) AS total_patient_resp,
    ROUND(SUM(fin.allowed_amount_usd - fin.patient_responsibility_usd), 2) AS net_revenue,
    ROUND(AVG(fin.allowed_amount_usd), 2) AS avg_revenue_per_claim,
    ROUND((1 - AVG(fin.allowed_amount_usd) / NULLIF(AVG(fin.submitted_charge_usd),0)) * 100, 2) AS avg_discount_pct
FROM gold.DIM_FINANCIAL fin
GROUP BY fin.payer
ORDER BY net_revenue DESC;
GO

-- ============================================================
-- Q4: Claim Denial Rate and Reasons Analysis
-- ============================================================
SELECT
    ISNULL(fin.denial_reason_code, 'CLEAN (Accepted)') AS denial_code,
    COUNT(fin.claim_id) AS claim_count,
    ROUND(COUNT(fin.claim_id) * 100.0 / SUM(COUNT(fin.claim_id)) OVER (), 2) AS pct_of_total,
    ROUND(SUM(fin.submitted_charge_usd), 2) AS revenue_at_risk
FROM gold.DIM_FINANCIAL fin
GROUP BY fin.denial_reason_code
ORDER BY claim_count DESC;
GO

-- ============================================================
-- Q5: Fraud, Waste, and Abuse (FWA) Detection and Financial Impact
-- ============================================================
SELECT
    CASE
        WHEN fin.fraud_upcoding_flag  = 1 THEN 'Upcoding'
        WHEN fin.fraud_duplicate_flag = 1 THEN 'Duplicate'
        WHEN fin.fraud_unbundling_flag= 1 THEN 'Unbundling'
        ELSE 'Clean'
    END AS fraud_type,
    COUNT(fin.claim_id) AS claim_count,
    ROUND(AVG(fin.submitted_charge_usd), 2) AS avg_submitted_charge,
    ROUND(AVG(fin.allowed_amount_usd), 2) AS avg_allowed,
    ROUND(SUM(CAST(fin.claim_denial_flag AS INT)) * 100.0 / COUNT(fin.claim_id), 2) AS denial_rate_pct
FROM gold.DIM_FINANCIAL fin
GROUP BY
    CASE
        WHEN fin.fraud_upcoding_flag  = 1 THEN 'Upcoding'
        WHEN fin.fraud_duplicate_flag = 1 THEN 'Duplicate'
        WHEN fin.fraud_unbundling_flag= 1 THEN 'Unbundling'
        ELSE 'Clean'
    END
ORDER BY avg_submitted_charge DESC;
GO

-- ============================================================
-- Q6: Operating Room (OR) Performance and Efficiency
-- ============================================================
SELECT
    op.cpt_code,
    op.procedure_display,
    COUNT(f.encounter_id) AS case_count,
    ROUND(AVG(CAST(op.actual_or_minutes AS FLOAT)), 1) AS avg_or_minutes,
    ROUND(AVG(CAST(op.or_turnover_minutes AS FLOAT)), 1) AS avg_turnover_minutes,
    ROUND(AVG(CAST(op.actual_or_minutes AS FLOAT)) / NULLIF(AVG(CAST(op.actual_or_minutes AS FLOAT)) + AVG(CAST(op.or_turnover_minutes AS FLOAT)), 0) * 100, 2) AS or_efficiency_pct
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_OPERATIONAL op ON f.encounter_id = op.encounter_id
GROUP BY op.cpt_code, op.procedure_display
ORDER BY avg_or_minutes DESC;
GO

-- ============================================================
-- Q7: Door-to-Doctor Wait Time and Occupancy Impact
-- ============================================================
SELECT
    CASE
        WHEN op.bed_occupancy_pct < 75  THEN 'Low  (<75%)' 
        WHEN op.bed_occupancy_pct < 85  THEN 'Normal (75-85%)'
        ELSE                                 'High  (>85%)'
    END AS occupancy_level,
    COUNT(f.encounter_id) AS encounters,
    ROUND(AVG(DATEDIFF(MINUTE, f.triage_timestamp, op.physician_assessment_timestamp)), 1) AS avg_door_to_doctor_mins,
    ROUND(AVG(DATEDIFF(MINUTE, op.bed_request_time, op.bed_assign_time)), 1) AS avg_bed_wait_mins
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_OPERATIONAL op ON f.encounter_id = op.encounter_id
WHERE op.physician_assessment_timestamp IS NOT NULL
GROUP BY
    CASE
        WHEN op.bed_occupancy_pct < 75 THEN 'Low  (<75%)'
        WHEN op.bed_occupancy_pct < 85 THEN 'Normal (75-85%)'
        ELSE                                'High  (>85%)'
    END
ORDER BY avg_door_to_doctor_mins;
GO

-- ============================================================
-- Q8: Nurse Burnout Impact on Safety Incidents
-- ============================================================
SELECT
    CASE
        WHEN hr.burnout_exhaustion_mbi < 2   THEN 'Low Burnout  (0-2)'
        WHEN hr.burnout_exhaustion_mbi < 3.5 THEN 'Mid Burnout  (2-3.5)'
        ELSE                                      'High Burnout (>3.5)'
    END AS burnout_level,
    COUNT(f.encounter_id) AS total_encounters,
    ROUND(AVG(CAST(hr.patients_per_nurse_ratio AS FLOAT)), 2) AS avg_patients_per_nurse,
    ROUND(AVG(CAST(hr.overtime_hours AS FLOAT)), 2) AS avg_overtime_hours,
    SUM(CAST(f.safety_incident_flag AS INT)) AS total_incidents,
    ROUND(SUM(CAST(f.safety_incident_flag AS FLOAT)) / COUNT(f.encounter_id) * 100, 2) AS incident_rate_pct,
    ROUND(AVG(hr.turnover_risk_index), 3) AS avg_turnover_risk
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_HR hr ON f.encounter_id = hr.encounter_id
GROUP BY
    CASE
        WHEN hr.burnout_exhaustion_mbi < 2   THEN 'Low Burnout  (0-2)'
        WHEN hr.burnout_exhaustion_mbi < 3.5 THEN 'Mid Burnout  (2-3.5)'
        ELSE                                      'High Burnout (>3.5)'
    END
ORDER BY incident_rate_pct DESC;
GO

-- ============================================================
-- Q9: HEDIS Quality Metrics: Diabetes Care Gap
-- ============================================================
SELECT
    p.race_ethnicity,
    COUNT(f.encounter_id) AS diabetic_encounters,
    SUM(CAST(c.hedis_hba1c_tested AS INT)) AS hba1c_tested,
    ROUND(SUM(CAST(c.hedis_hba1c_tested AS FLOAT)) / COUNT(f.encounter_id) * 100, 2) AS testing_rate_pct,
    SUM(CAST(c.hedis_hba1c_poor_control AS INT)) AS poor_control_count,
    ROUND(SUM(CAST(c.hedis_hba1c_poor_control AS FLOAT)) / COUNT(f.encounter_id) * 100, 2) AS poor_control_rate_pct
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_PATIENT   p ON f.patient_id    = p.patient_id
JOIN gold.DIM_CLINICAL  c ON f.encounter_id  = c.encounter_id
WHERE c.has_diabetes = 1
GROUP BY p.race_ethnicity
ORDER BY poor_control_rate_pct DESC;
GO

-- ============================================================
-- Q10: Supply Cost Analysis per Procedure
-- ============================================================
SELECT
    s.kit_name,
    COUNT(f.encounter_id) AS usage_count,
    ROUND(AVG(CAST(s.kit_unit_cost_usd AS FLOAT)), 2) AS avg_kit_cost,
    ROUND(AVG(fin.consumable_supply_cost_usd), 2) AS avg_consumable_cost,
    ROUND(AVG(CAST(s.kit_unit_cost_usd AS FLOAT) + fin.consumable_supply_cost_usd), 2) AS avg_total_supply_cost,
    ROUND(SUM(CAST(s.kit_unit_cost_usd AS FLOAT) + fin.consumable_supply_cost_usd), 2) AS total_supply_spend,
    ROUND(AVG(fin.allowed_amount_usd), 2) AS avg_revenue
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_SUPPLY   s   ON f.surgical_kit_id = s.surgical_kit_id
JOIN gold.DIM_FINANCIAL fin ON f.encounter_id   = fin.encounter_id
GROUP BY s.kit_name
ORDER BY avg_total_supply_cost DESC;
GO

-- ============================================================
-- Q11: CAHPS Patient Experience Scores by Unit
-- ============================================================
SELECT
    op.unit_assigned,
    COUNT(f.encounter_id) AS encounters,
    ROUND(AVG(hr.cahps_nurse_communication), 2) AS nurse_comm_score,
    ROUND(AVG(hr.cahps_doctor_communication), 2) AS doctor_comm_score,
    ROUND(AVG(hr.cahps_responsiveness), 2) AS responsiveness_score,
    ROUND(AVG(hr.cahps_care_transition), 2) AS care_transition_score,
    ROUND(AVG(hr.cahps_discharge_info), 2) AS discharge_info_score,
    ROUND((AVG(hr.cahps_nurse_communication) + AVG(hr.cahps_doctor_communication) + AVG(hr.cahps_responsiveness) + AVG(hr.cahps_pain_management) + AVG(hr.cahps_discharge_info) + AVG(hr.cahps_care_transition) + AVG(hr.cahps_cleanliness) + AVG(hr.cahps_quietness)) / 8, 2) AS cahps_composite_score
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_HR          hr ON f.encounter_id  = hr.encounter_id
JOIN gold.DIM_OPERATIONAL op ON f.encounter_id  = op.encounter_id
GROUP BY op.unit_assigned
ORDER BY cahps_composite_score;
GO

-- ============================================================
-- Q12: Health Equity and Disparities Analysis
-- ============================================================
SELECT
    p.race_ethnicity,
    p.gender AS sex,
    COUNT(f.encounter_id) AS encounters,
    ROUND(AVG(c.severity_index), 3) AS avg_severity,
    ROUND(AVG(CAST(f.readmission_30d_flag AS FLOAT))*100,2) AS readmission_rate_pct,
    ROUND(AVG(CAST(f.hai_flag AS FLOAT))*100, 2) AS hai_rate_pct,
    ROUND(AVG(fin.patient_responsibility_usd), 2) AS avg_patient_cost,
    ROUND(AVG(CAST(hr.telehealth_used_flag AS FLOAT))*100,2) AS telehealth_adoption_pct
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_PATIENT   p   ON f.patient_id   = p.patient_id
JOIN gold.DIM_CLINICAL  c   ON f.encounter_id = c.encounter_id
JOIN gold.DIM_FINANCIAL fin ON f.encounter_id = fin.encounter_id
JOIN gold.DIM_HR        hr  ON f.encounter_id = hr.encounter_id
GROUP BY p.race_ethnicity, p.gender
ORDER BY readmission_rate_pct DESC;
GO

-- ============================================================
-- Q13: Supply Chain Stockout Risk Alert
-- ============================================================
SELECT
    s.surgical_kit_id,
    s.kit_name,
    s.kit_current_stock,
    s.kit_reorder_point,
    ROUND(s.days_of_supply, 1) AS days_of_supply,
    s.kit_lead_time_days,
    s.projected_demand_4wk,
    s.kit_expiration_date,
    CASE
        WHEN s.days_of_supply < 7  THEN 'CRITICAL - Order Now'
        WHEN s.days_of_supply < 14 THEN 'WARNING  - Order Soon'
        ELSE                            'OK'
    END AS supply_status,
    COUNT(f.encounter_id) AS recent_usage_count
FROM gold.DIM_SUPPLY s
LEFT JOIN gold.FACT_ENCOUNTERS f ON s.surgical_kit_id = f.surgical_kit_id
GROUP BY s.surgical_kit_id, s.kit_name, s.kit_current_stock, s.kit_reorder_point, s.days_of_supply, s.kit_lead_time_days, s.projected_demand_4wk, s.kit_expiration_date
ORDER BY s.days_of_supply;
GO

-- ============================================================
-- Q14: Surgeon Performance by Specialty
-- ============================================================
SELECT
    hr.surgeon_specialty,
    COUNT(f.encounter_id) AS total_cases,
    ROUND(AVG(CAST(op.actual_or_minutes AS FLOAT)), 1)  AS avg_or_minutes,
    ROUND(AVG(CAST(op.or_turnover_minutes AS FLOAT)),1) AS avg_turnover_minutes,
    ROUND(AVG(CAST(op.actual_or_minutes AS FLOAT)) / NULLIF(AVG(CAST(op.actual_or_minutes AS FLOAT)) + AVG(CAST(op.or_turnover_minutes AS FLOAT)),0)*100, 2) AS or_efficiency_pct,
    ROUND(AVG(CAST(f.readmission_30d_flag AS FLOAT))*100,2) AS readmission_rate_pct,
    ROUND(AVG(fin.allowed_amount_usd), 2) AS avg_revenue_per_case
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_HR          hr  ON f.encounter_id = hr.encounter_id
JOIN gold.DIM_OPERATIONAL op  ON f.encounter_id = op.encounter_id
JOIN gold.DIM_FINANCIAL   fin ON f.encounter_id = fin.encounter_id
GROUP BY hr.surgeon_specialty
ORDER BY or_efficiency_pct DESC;
GO

-- ============================================================
-- Q15: Hospital-Acquired Infection (HAI) Rate by Unit
-- ============================================================
SELECT
    op.unit_assigned,
    COUNT(f.encounter_id) AS total_encounters,
    SUM(CAST(f.hai_flag AS INT)) AS hai_cases,
    ROUND(SUM(CAST(f.hai_flag AS FLOAT)) / COUNT(f.encounter_id) * 100, 2) AS hai_rate_pct,
    ROUND(SUM(CAST(f.hai_flag AS FLOAT)) / NULLIF(SUM(CAST(f.los_days AS FLOAT)),0) * 1000, 2) AS hai_per_1000_patient_days,
    ROUND(AVG(CAST(f.los_days AS FLOAT)), 1) AS avg_los_days,
    ROUND(AVG(op.bed_occupancy_pct), 1) AS avg_occupancy_pct
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_OPERATIONAL op ON f.encounter_id = op.encounter_id
GROUP BY op.unit_assigned
ORDER BY hai_rate_pct DESC;
GO

-- ============================================================
-- Q16: Burnout Risk Ratio and Projected Turnover Cost
-- ============================================================
SELECT
    hr.nurse_role,
    hr.nurse_unit,
    COUNT(DISTINCT hr.nurse_emp_id) AS nurse_count,
    ROUND(AVG(hr.burnout_exhaustion_mbi), 2) AS avg_burnout_score,
    ROUND(AVG(hr.turnover_risk_index), 3) AS avg_turnover_risk,
    SUM(CASE WHEN hr.turnover_risk_index > 0.6 THEN 1 ELSE 0 END) AS high_risk_nurses,
    ROUND(SUM(CASE WHEN hr.turnover_risk_index > 0.6 THEN 1 ELSE 0 END) * 50000.0, 0) AS projected_turnover_cost_usd
FROM gold.DIM_HR hr
JOIN gold.FACT_ENCOUNTERS f ON hr.encounter_id = f.encounter_id
GROUP BY hr.nurse_role, hr.nurse_unit
ORDER BY avg_turnover_risk DESC;
GO

-- ============================================================
-- Q17: Geographic Distribution of Patients and Performance Metrics
-- ============================================================
SELECT TOP 15
    p.state,
    COUNT(f.encounter_id) AS total_encounters,
    ROUND(AVG(CAST(f.readmission_30d_flag AS FLOAT))*100,2) AS readmission_rate_pct,
    ROUND(AVG(CAST(f.hai_flag AS FLOAT))*100, 2) AS hai_rate_pct,
    ROUND(AVG(fin.allowed_amount_usd), 2) AS avg_revenue,
    ROUND(AVG(fin.patient_responsibility_usd), 2) AS avg_patient_burden,
    ROUND(AVG(CAST(hr.telehealth_used_flag AS FLOAT))*100,2) AS telehealth_pct
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_PATIENT   p   ON f.patient_id   = p.patient_id
JOIN gold.DIM_FINANCIAL fin ON f.encounter_id = fin.encounter_id
JOIN gold.DIM_HR        hr  ON f.encounter_id = hr.encounter_id
GROUP BY p.state
ORDER BY readmission_rate_pct DESC;
GO

-- ============================================================
-- Q18: Window Function: Ranking Procedures by Revenue (RANK)
-- ============================================================
WITH procedure_revenue AS (
    SELECT
        c.diagnosis_category,
        op.procedure_display,
        COUNT(f.encounter_id) AS case_count,
        ROUND(AVG(fin.allowed_amount_usd),2) AS avg_revenue,
        ROUND(SUM(fin.allowed_amount_usd),2) AS total_revenue
    FROM gold.FACT_ENCOUNTERS f
    JOIN gold.DIM_CLINICAL    c   ON f.encounter_id = c.encounter_id
    JOIN gold.DIM_OPERATIONAL op  ON f.encounter_id = op.encounter_id
    JOIN gold.DIM_FINANCIAL   fin ON f.encounter_id = fin.encounter_id
    GROUP BY c.diagnosis_category, op.procedure_display
)
SELECT
    diagnosis_category,
    procedure_display,
    case_count,
    avg_revenue,
    total_revenue,
    RANK() OVER (PARTITION BY diagnosis_category ORDER BY avg_revenue DESC) AS revenue_rank
FROM procedure_revenue
ORDER BY diagnosis_category, revenue_rank;
GO

-- ============================================================
-- Q19: Window Function: Cumulative Running Total for Revenue
-- ============================================================
SELECT
    d.year,
    d.month,
    d.month_name,
    ROUND(SUM(fin.allowed_amount_usd - fin.patient_responsibility_usd),2) AS monthly_net_revenue,
    ROUND(SUM(SUM(fin.allowed_amount_usd - fin.patient_responsibility_usd)) 
          OVER (ORDER BY d.year, d.month ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),2) AS cumulative_net_revenue,
    ROUND(AVG(SUM(fin.allowed_amount_usd - fin.patient_responsibility_usd)) 
          OVER (ORDER BY d.year, d.month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),2) AS moving_avg_3m_revenue
FROM gold.DIM_FINANCIAL fin
JOIN gold.FACT_ENCOUNTERS f ON fin.encounter_id = f.encounter_id
JOIN gold.DIM_DATE        d ON f.admit_date_key = d.date_key
GROUP BY d.year, d.month, d.month_name
ORDER BY d.year, d.month;
GO

-- ============================================================
-- Q20: Comprehensive Executive KPI Summary
-- ============================================================
SELECT
    COUNT(f.encounter_id) AS total_encounters,
    COUNT(DISTINCT f.patient_id) AS unique_patients,
    ROUND(AVG(CAST(f.readmission_30d_flag AS FLOAT))*100, 2) AS readmission_rate_pct,
    ROUND(AVG(CAST(f.hai_flag AS FLOAT))*100, 2) AS hai_rate_pct,
    ROUND(AVG(CAST(f.safety_incident_flag AS FLOAT))*100, 2) AS safety_incident_rate_pct,
    ROUND(AVG(CAST(f.follow_up_within_48h_flag AS FLOAT))*100, 2) AS followup_compliance_pct,
    ROUND(AVG(CAST(f.los_days AS FLOAT)), 2) AS avg_los_days,
    ROUND(SUM(fin.submitted_charge_usd), 2) AS total_submitted_charges,
    ROUND(SUM(fin.allowed_amount_usd - fin.patient_responsibility_usd), 2) AS total_net_revenue,
    ROUND(AVG(CAST(fin.claim_denial_flag AS FLOAT))*100, 2) AS denial_rate_pct,
    ROUND(AVG(hr.burnout_exhaustion_mbi), 2) AS avg_burnout_score,
    ROUND(AVG(hr.patients_per_nurse_ratio), 2) AS avg_nurse_ratio,
    ROUND(AVG(hr.cahps_nurse_communication + hr.cahps_doctor_communication + hr.cahps_responsiveness + hr.cahps_pain_management + hr.cahps_discharge_info + hr.cahps_care_transition + hr.cahps_cleanliness + hr.cahps_quietness) / 8, 2) AS cahps_composite_score,
    ROUND(AVG(CAST(s.kit_unit_cost_usd AS FLOAT) + fin.consumable_supply_cost_usd), 2) AS avg_supply_cost_per_encounter
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_PATIENT   p   ON f.patient_id      = p.patient_id
JOIN gold.DIM_FINANCIAL fin ON f.encounter_id    = fin.encounter_id
JOIN gold.DIM_HR        hr  ON f.encounter_id    = hr.encounter_id
JOIN gold.DIM_SUPPLY    s   ON f.surgical_kit_id = s.surgical_kit_id;
GO