/*
SCRIPT  : Creating_Indexes_for_Lightning_Speed.sql
PURPOSE : Create Columnstore + Standard Indexes and the 5 Power BI Views.
*/
USE HealthcareDB;
GO

-- ============================================================
-- SECTION 1 — Indexes (Do not run Creating_Standard_Indexes.sql again)
-- ============================================================

PRINT 'Creating Indexes...';

-- FACT_ENCOUNTERS — Most frequently used columns in JOIN and WHERE clauses
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FACT_PATIENT')
    CREATE INDEX IX_FACT_PATIENT   ON gold.FACT_ENCOUNTERS(patient_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FACT_DATE')
    CREATE INDEX IX_FACT_DATE      ON gold.FACT_ENCOUNTERS(admit_date_key);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FACT_KIT')
    CREATE INDEX IX_FACT_KIT       ON gold.FACT_ENCOUNTERS(surgical_kit_id);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FACT_READMIT')
    CREATE INDEX IX_FACT_READMIT   ON gold.FACT_ENCOUNTERS(readmission_30d_flag);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FACT_HAI')
    CREATE INDEX IX_FACT_HAI       ON gold.FACT_ENCOUNTERS(hai_flag);

-- DIMENSION Indexes
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CLIN_CATEGORY')
    CREATE INDEX IX_CLIN_CATEGORY  ON gold.DIM_CLINICAL(diagnosis_category);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CLIN_SEVERITY')
    CREATE INDEX IX_CLIN_SEVERITY  ON gold.DIM_CLINICAL(severity_index);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CLIN_DIABETES')
    CREATE INDEX IX_CLIN_DIABETES  ON gold.DIM_CLINICAL(has_diabetes);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FIN_PAYER')
    CREATE INDEX IX_FIN_PAYER      ON gold.DIM_FINANCIAL(payer);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FIN_DENIAL')
    CREATE INDEX IX_FIN_DENIAL     ON gold.DIM_FINANCIAL(claim_denial_flag);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_FIN_FRAUD')
    CREATE INDEX IX_FIN_FRAUD      ON gold.DIM_FINANCIAL(fraud_upcoding_flag, fraud_duplicate_flag);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PAT_STATE')
    CREATE INDEX IX_PAT_STATE      ON gold.DIM_PATIENT(state);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PAT_RACE')
    CREATE INDEX IX_PAT_RACE       ON gold.DIM_PATIENT(race_ethnicity);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_HR_BURNOUT')
    CREATE INDEX IX_HR_BURNOUT     ON gold.DIM_HR(burnout_exhaustion_mbi);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_HR_TURNOVER')
    CREATE INDEX IX_HR_TURNOVER    ON gold.DIM_HR(turnover_risk_index);

GO
PRINT '✅ All Indexes Created!';
GO

-- ============================================================
-- SECTION 2 — Power BI Views
-- ============================================================

PRINT 'Creating Views...';
GO

-- View 1: Executive KPIs
-- [FIX] Added d.quarter to leverage the new column in DIM_DATE
CREATE OR ALTER VIEW gold.VW_EXECUTIVE_KPIs AS
SELECT
    d.year,
    d.quarter,
    d.month,
    d.month_name,
    c.diagnosis_category,
    p.state,
    COUNT(f.encounter_id)                                          AS total_encounters,
    ROUND(AVG(CAST(f.readmission_30d_flag AS FLOAT))*100, 2)      AS readmission_pct,
    ROUND(AVG(CAST(f.hai_flag AS FLOAT))*100, 2)                  AS hai_pct,
    ROUND(SUM(fin.allowed_amount_usd - fin.patient_responsibility_usd), 2) AS net_revenue,
    ROUND(AVG(CAST(f.los_days AS FLOAT)), 2)                      AS avg_los
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_DATE      d   ON f.admit_date_key = d.date_key
JOIN gold.DIM_PATIENT   p   ON f.patient_id     = p.patient_id
JOIN gold.DIM_CLINICAL  c   ON f.encounter_id   = c.encounter_id
JOIN gold.DIM_FINANCIAL fin ON f.encounter_id   = fin.encounter_id
GROUP BY d.year, d.quarter, d.month, d.month_name, c.diagnosis_category, p.state;
GO

-- View 2: Clinical Quality
CREATE OR ALTER VIEW gold.VW_CLINICAL_QUALITY AS
SELECT
    f.encounter_id,
    c.diagnosis_category,
    c.severity_index,
    c.comorbidity_count,
    c.has_diabetes,
    c.has_chf,
    c.medication_adherence_pdc,
    c.hba1c_pct,
    c.hedis_hba1c_tested,
    c.hedis_hba1c_poor_control,
    f.readmission_30d_flag,
    f.hai_flag,
    f.follow_up_within_48h_flag,
    f.safety_incident_flag,
    op.incident_type,
    op.incident_severity,
    f.los_days,
    op.unit_assigned,
    p.race_ethnicity,
    p.age,
    p.gender
FROM gold.FACT_ENCOUNTERS f
JOIN gold.DIM_CLINICAL    c  ON f.encounter_id = c.encounter_id
JOIN gold.DIM_OPERATIONAL op ON f.encounter_id = op.encounter_id
JOIN gold.DIM_PATIENT     p  ON f.patient_id   = p.patient_id;
GO

-- View 3: Financial Summary
CREATE OR ALTER VIEW gold.VW_FINANCIAL_SUMMARY AS
SELECT
    fin.claim_id,
    f.encounter_id,
    fin.payer,
    fin.drg_weight,
    fin.submitted_charge_usd,
    fin.allowed_amount_usd,
    fin.patient_responsibility_usd,
    (fin.allowed_amount_usd - fin.patient_responsibility_usd)              AS net_revenue,
    fin.submitted_charge_usd / NULLIF(fin.allowed_amount_usd, 0)           AS charge_markup_ratio,
    fin.fraud_upcoding_flag,
    fin.fraud_duplicate_flag,
    fin.fraud_unbundling_flag,
    CASE WHEN fin.fraud_upcoding_flag  = 1
           OR fin.fraud_duplicate_flag = 1
           OR fin.fraud_unbundling_flag= 1
         THEN 1 ELSE 0 END                                                  AS fraud_any_flag,
    fin.claim_denial_flag,
    ISNULL(fin.denial_reason_code, 'CLEAN')                                AS denial_reason,
    fin.equipment_type,
    fin.equipment_usage_minutes,
    fin.consumable_supply_cost_usd,
    c.diagnosis_category,
    p.state
FROM gold.DIM_FINANCIAL fin
JOIN gold.FACT_ENCOUNTERS f ON fin.encounter_id = f.encounter_id
JOIN gold.DIM_CLINICAL    c ON f.encounter_id   = c.encounter_id
JOIN gold.DIM_PATIENT     p ON f.patient_id     = p.patient_id;
GO

-- View 4: HR & Burnout
CREATE OR ALTER VIEW gold.VW_HR_BURNOUT AS
SELECT
    hr.encounter_id,
    hr.nurse_emp_id,
    hr.nurse_role,
    hr.nurse_unit,
    hr.nurse_tenure_years,
    hr.patients_per_nurse_ratio,
    hr.overtime_hours,
    hr.burnout_exhaustion_mbi,
    hr.burnout_cynicism_mbi,
    (hr.burnout_exhaustion_mbi + hr.burnout_cynicism_mbi) / 2              AS burnout_composite,
    hr.turnover_risk_index,
    CASE WHEN hr.turnover_risk_index > 0.6 THEN 1 ELSE 0 END               AS high_risk_flag,
    hr.shift_hours,
    f.safety_incident_flag,
    op.unit_assigned,
    (hr.cahps_nurse_communication + hr.cahps_doctor_communication
   + hr.cahps_responsiveness    + hr.cahps_pain_management
   + hr.cahps_discharge_info    + hr.cahps_care_transition
   + hr.cahps_cleanliness       + hr.cahps_quietness) / 8.0                AS cahps_composite
FROM gold.DIM_HR hr
JOIN gold.FACT_ENCOUNTERS  f  ON hr.encounter_id = f.encounter_id
JOIN gold.DIM_OPERATIONAL  op ON hr.encounter_id = op.encounter_id;
GO

-- View 5: Supply Chain Risk
CREATE OR ALTER VIEW gold.VW_SUPPLY_RISK AS
SELECT
    s.surgical_kit_id,
    s.kit_name,
    s.kit_unit_cost_usd,
    s.kit_current_stock,
    s.kit_reorder_point,
    s.kit_lead_time_days,
    s.kit_expiration_date,
    s.days_of_supply,
    s.weekly_procedure_volume,
    s.projected_demand_4wk,
    s.stockout_risk_flag,
    CASE
        WHEN s.days_of_supply < 7  THEN 'CRITICAL'
        WHEN s.days_of_supply < 14 THEN 'WARNING'
        ELSE                            'OK'
    END                                                                     AS supply_status,
    CASE
        WHEN s.kit_expiration_date <= DATEADD(DAY, s.kit_lead_time_days, GETDATE())
        THEN 1 ELSE 0
    END                                                                     AS expiry_risk_flag,
    COUNT(f.encounter_id)                                                   AS total_usage
FROM gold.DIM_SUPPLY s
LEFT JOIN gold.FACT_ENCOUNTERS f ON s.surgical_kit_id = f.surgical_kit_id
GROUP BY s.surgical_kit_id, s.kit_name, s.kit_unit_cost_usd,
         s.kit_current_stock, s.kit_reorder_point, s.kit_lead_time_days,
         s.kit_expiration_date, s.days_of_supply, s.weekly_procedure_volume,
         s.projected_demand_4wk, s.stockout_risk_flag;
GO

PRINT '✅ ALL VIEWS AND INDEXES CREATED SUCCESSFULLY! READY FOR POWER BI.';
GO